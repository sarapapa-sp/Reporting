import json
from pathlib import Path
from datetime import datetime
from app.services.file_service import resolve_section_path, file_status

def _read_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def load_report(report_id: str, business_date: str, version: str,
                registry_path: Path, mapping_path: Path, data_root: Path):
    if not report_id:
        raise ValueError("Please select a report.")
    try:
        datetime.strptime(business_date, "%Y-%m-%d")
    except ValueError:
        raise ValueError("Select a valid business date.")
    if version not in ("Daily", "Flash", "Final"):
        raise ValueError("Select a valid report version.")

    registry = _read_json(registry_path)
    report_map = {r["id"]: r for r in registry.get("reports", [])}
    if report_id not in report_map:
        raise ValueError("Unknown report selection.")

    if not mapping_path.is_file():
        return {
            "status": "error",
            "message": "Report mapping configuration is missing.",
            "sections": [],
            "metadata": []
        }

    mapping = _read_json(mapping_path)
    report_def = report_map[report_id]
    sections = []
    metadata = []
    missing = []

    for section_def in report_def.get("sections", []):
        path = resolve_section_path(
            data_root, section_def["file_pattern"], business_date, version
        )
        status = file_status(path)
        row = {
            "section_id": section_def["id"],
            "section_name": section_def["name"],
            "file_name": path.name,
            "status": status,
            "rows": 0,
            "last_modified": None
        }
        if status != "Loaded":
            missing.append(path.name)
            sections.append({**row, "data": None})
            metadata.append(row)
            continue

        try:
            data = _read_json(path)
        except (OSError, json.JSONDecodeError):
            row["status"] = "Invalid JSON"
            missing.append(path.name)
            sections.append({**row, "data": None})
            metadata.append(row)
            continue

        row["rows"] = len(data.get("rows", [])) if isinstance(data, dict) else 0
        row["last_modified"] = datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
        sections.append({**row, "data": data})
        metadata.append(row)

    if missing:
        status = "missing"
        message = "Data not generated yet for one or more sections."
    else:
        status = "loaded"
        message = "All data files loaded successfully."

    return {
        "status": status,
        "message": message,
        "report_id": report_id,
        "report_name": report_def["name"],
        "business_date": business_date,
        "version": version,
        "mapping": mapping,
        "sections": sections,
        "metadata": metadata
    }
