from pathlib import Path


def resolve_section_path(data_root: Path, file_pattern: str, business_date: str, version: str) -> Path:
    """Resolve a report file under Report_name/daily|eom/[flash|final]/YYYY/MM/DD."""
    year, month, day = business_date.split("-")
    parts = Path(file_pattern).parts
    if len(parts) < 2:
        raise ValueError("Invalid report file configuration.")
    report_folder = parts[0]
    filename_pattern = parts[-1]
    period = "daily" if version.lower() == "daily" else "eom"
    relative_parts = [report_folder, period]
    if period == "eom":
        relative_parts.append(version.lower())
    relative_parts.extend([year, month, day])
    filename = filename_pattern.format(year=year, month=month, day=day,
                                       date=f"{year}{month}{day}", version=version.lower())
    root = data_root.resolve()
    path = (root.joinpath(*relative_parts, filename)).resolve()
    if root != path and root not in path.parents:
        raise ValueError("Invalid report file configuration.")
    return path


def available_dates(report_def: dict, data_root: Path, versions: list[str]) -> list[dict]:
    """Discover business dates that have all section files for at least one version."""
    from datetime import datetime
    found = {}
    for version in versions:
        for section in report_def.get("sections", []):
            pattern = section.get("file_pattern", "")
            parts = Path(pattern).parts
            if len(parts) < 2:
                continue
            folder = parts[0]
            period = "daily" if version.lower() == "daily" else "eom"
            scan_root = data_root / folder / period
            if period == "eom":
                scan_root = scan_root / version.lower()
            if not scan_root.is_dir():
                continue
            for path in scan_root.glob("*/*/*/*.json"):
                try:
                    date_value = datetime.strptime("-".join(path.parts[-4:-1]), "%Y-%m-%d")
                except ValueError:
                    # Folder layout is YYYY/MM/DD, so parse the final three folders explicitly.
                    try:
                        date_value = datetime.strptime("/".join(path.parts[-4:-1]), "%Y/%m/%d")
                    except ValueError:
                        continue
                expected = resolve_section_path(data_root, pattern, date_value.strftime("%Y-%m-%d"), version)
                if expected.is_file():
                    key = date_value.strftime("%Y-%m-%d")
                    found.setdefault(key, set()).add(version)
    return [{"date": date, "versions": sorted(v, key=lambda x: ["Daily", "Flash", "Final"].index(x))}
            for date, v in sorted(found.items(), reverse=True)]


def file_status(path: Path) -> str:
    return "Loaded" if path.is_file() else "Not generated yet"
