from functools import wraps
from flask import abort
from app.auth.user_context import get_current_user

def roles_required(*allowed_roles):
    def decorator(view_func):
        @wraps(view_func)
        def wrapped(*args, **kwargs):
            user = get_current_user()
            if user.get("role") not in allowed_roles:
                abort(403, description="User does not have permission to access this page.")
            return view_func(*args, **kwargs)
        return wrapped
    return decorator
