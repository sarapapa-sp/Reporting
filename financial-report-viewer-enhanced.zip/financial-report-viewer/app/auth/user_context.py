from flask import current_app, abort, request
import json

def get_user_id():
    """Resolve the logged-in user ID from a trusted internal SSO/reverse-proxy header.

    Configure USER_ID_HEADER (default REMOTE_USER) to match your environment.
    The trusted gateway must set this header and strip any client-supplied copy.
    No application login page is provided.
    """
    header_name = current_app.config.get("USER_ID_HEADER", "REMOTE_USER")
    user_id = request.headers.get(header_name, "").strip()
    if not user_id:
        abort(403, description="User does not have permission to access.")
    try:
        with open(current_app.config["USERS_PATH"], "r", encoding="utf-8") as f:
            users = json.load(f)
    except (OSError, json.JSONDecodeError):
        abort(500, description="User configuration could not be read.")
    if user_id not in users:
        abort(403, description="User does not have permission to access.")
    return user_id

def get_current_user():
    user_id = get_user_id()
    with open(current_app.config["USERS_PATH"], "r", encoding="utf-8") as f:
        users = json.load(f)
    user = users[user_id].copy()
    user["user_id"] = user_id
    return user
