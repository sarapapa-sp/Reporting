(() => {
  const cfg = window.REPORT_VIEWER_CONFIG;
  const form = document.getElementById("report-form");
  const statusBox = document.getElementById("report-status");
  const sectionsContainer = document.getElementById("sections-container");
  const refreshBtn = document.getElementById("refresh-btn");
  const metadataPanel = document.getElementById("metadata-panel");
  const metadataBody = document.getElementById("metadata-body");
  const metadataCount = document.getElementById("metadata-count");

  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[c]));

  function formatValue(value, category) {
    if (value === null || value === undefined || value === "") return "—";
    if (typeof value === "number") {
      if (category === "percentage" || category === "percentage_arrow") {
        return `${value.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}%`;
      }
      return value.toLocaleString(undefined, {maximumFractionDigits: 2});
    }
    return String(value);
  }

  function getColumnDefs(mapping) {
    if (Array.isArray(mapping.columns)) return mapping.columns;
    if (mapping.columns && typeof mapping.columns === "object") {
      return Object.entries(mapping.columns).map(([key, value]) => ({key, ...value}));
    }
    return [];
  }

  function renderSection(section, index, mapping) {
    const data = section.data;
    if (!data) {
      const missing = section.status === "Not generated yet";
      return `<section class="section-card"><div class="section-head"><div class="section-title"><span class="section-number">${index + 1}</span><div><h2>${escapeHtml(section.section_name)}</h2><div class="section-file">${escapeHtml(section.file_name)}</div></div></div><div class="section-actions"><span class="${missing ? 'status-missing' : 'status-invalid'}">${escapeHtml(section.status)}</span><button type="button" class="btn small secondary collapse-section" aria-expanded="true">Collapse</button></div></div><div class="section-body"><div class="empty-state"><strong>${missing ? 'Data not generated yet' : 'Unable to read report data'}</strong>${missing ? 'The expected JSON file has not been generated for this date and version.' : 'The file may be malformed or unreadable.'}</div></div></section>`;
    }

    const columns = getColumnDefs(mapping);
    const rows = Array.isArray(data.rows) ? data.rows : [];
    const columnKeys = columns.length
      ? columns.map(c => c.key || c.mapping_name || c.name).filter(Boolean)
      : [...new Set(rows.flatMap(row => Object.keys(row).filter(k => !["name","label","level","children","id"].includes(k))))];
    const labelKey = data.label_key || "name";

    const headers = columnKeys.map(key => {
      const col = columns.find(c => (c.key || c.mapping_name || c.name) === key) || {};
      const title = col.display_name || col.label || col.mapping_name || key;
      const color = col.color_grading === "green" ? "#07885f" : (col.color_grading === "dark_grey" ? "#35465a" : "#65768a");
      return `<th style="background:${color}">${escapeHtml(title)}</th>`;
    }).join("");

    let treeRowCounter = 0;
    function renderRows(items, level=0, parentId="") {
      return items.map(row => {
        const rowId = `section-${index}-tree-row-${++treeRowCounter}`;
        const label = row[labelKey] ?? row.name ?? row.label ?? "—";
        const hasChildren = Array.isArray(row.children) && row.children.length > 0;
        const cells = columnKeys.map(key => {
          const col = columns.find(c => (c.key || c.mapping_name || c.name) === key) || {};
          const value = row[key];
          const category = col.category || "";
          let display = formatValue(value, category);
          if (category === "percentage_arrow" && typeof value === "number") {
            display = `<span class="arrow ${value >= 0 ? 'up' : 'down'}">${value >= 0 ? '▲' : '▼'}</span> ${formatValue(Math.abs(value), "percentage")}`;
          }
          return `<td>${display}</td>`;
        }).join("");
        const total = row.is_total ? "total-row" : "";
        const toggle = hasChildren ? `<button type="button" class="tree-toggle" data-tree-target="${rowId}" aria-expanded="true" title="Collapse children">⌄</button>` : '<span class="tree-toggle leaf">·</span>';
        const rowHtml = `<tr id="${rowId}" data-parent-row="${parentId}" class="tree-row ${total} level-${Math.min(level,4)}"><td>${toggle}${escapeHtml(label)}</td>${cells}</tr>`;
        return rowHtml + (hasChildren ? renderRows(row.children, level + 1, rowId) : "");
      }).join("");
    }

    return `<section class="section-card"><div class="section-head"><div class="section-title"><span class="section-number">${index + 1}</span><div><h2>${escapeHtml(section.section_name)}</h2><div class="section-file">Data: ${escapeHtml(section.file_name)}</div></div></div><div class="section-actions"><div class="section-meta">Rows: ${section.rows}</div><button type="button" class="btn small secondary collapse-section" aria-expanded="true">Collapse</button></div></div><div class="section-body"><div class="section-table"><table><thead><tr><th>Business Unit / Desk / Portfolio</th>${headers}</tr></thead><tbody>${rows.length ? renderRows(rows) : `<tr><td colspan="${columnKeys.length + 1}" class="empty-state">No rows in this generated file.</td></tr>`}</tbody></table></div></div></section>`;
  }

  function renderMetadata(items) {
    if (!cfg.showMetadata || !metadataPanel || !metadataBody) return;
    metadataBody.innerHTML = items.map((item, i) => `<tr><td>${i + 1}</td><td>${escapeHtml(item.section_name)}</td><td>${escapeHtml(item.file_name)}</td><td class="${item.status === 'Loaded' ? 'status-loaded' : 'status-missing'}">${escapeHtml(item.status)}</td><td>${item.rows ?? 0}</td><td>${escapeHtml(item.last_modified || '—')}</td></tr>`).join("");
    metadataCount.textContent = `${items.filter(x => x.status === "Loaded").length} of ${items.length} files loaded`;
    metadataPanel.classList.remove("hidden");
  }

  async function loadReport() {
    const params = new URLSearchParams(new FormData(form));
    statusBox.className = "status-banner info";
    statusBox.textContent = "Checking report files…";
    sectionsContainer.innerHTML = "";
    if (metadataPanel) metadataPanel.classList.add("hidden");
    try {
      const response = await fetch(`${cfg.apiUrl}?${params.toString()}`, {headers: {"Accept":"application/json"}});
      const result = await response.json();
      if (!response.ok || result.status === "error") {
        statusBox.className = "status-banner error";
        statusBox.textContent = result.message || "Unable to load report.";
        return;
      }
      statusBox.className = `status-banner ${result.status === "loaded" ? "success" : "warning"}`;
      statusBox.textContent = result.message;
      sectionsContainer.innerHTML = result.sections.map((s, i) => renderSection(s, i, result.mapping || {})).join("");
      renderMetadata(result.metadata || []);
      sectionsContainer.querySelectorAll(".tree-toggle[data-tree-target]").forEach(button => {
        button.addEventListener("click", () => {
          const targetId = button.dataset.treeTarget;
          const collapse = button.getAttribute("aria-expanded") === "true";
          const hideDescendants = parentId => {
            sectionsContainer.querySelectorAll(`[data-parent-row="${parentId}"]`).forEach(child => {
              child.hidden = collapse;
              const childToggle = child.querySelector(".tree-toggle[data-tree-target]");
              if (childToggle) { childToggle.setAttribute("aria-expanded", String(!collapse)); childToggle.textContent = collapse ? "›" : "⌄"; hideDescendants(child.id); }
            });
          };
          button.setAttribute("aria-expanded", String(!collapse)); button.textContent = collapse ? "›" : "⌄";
          hideDescendants(targetId);
        });
      });
      sectionsContainer.querySelectorAll(".collapse-section").forEach(button => {
        button.addEventListener("click", () => {
          const body = button.closest(".section-card").querySelector(".section-body");
          const isExpanded = button.getAttribute("aria-expanded") === "true";
          body.hidden = isExpanded;
          button.setAttribute("aria-expanded", String(!isExpanded));
          button.textContent = isExpanded ? "Expand" : "Collapse";
        });
      });
    } catch (error) {
      statusBox.className = "status-banner error";
      statusBox.textContent = "Could not contact the report viewer. Please try again.";
    }
  }


  form.addEventListener("submit", event => {
    event.preventDefault();
    loadReport();
  });
  refreshBtn.addEventListener("click", loadReport);

  // Load the selected report automatically on initial page load.
  loadReport();
})();
