from flask import Flask

def create_app():
    app = Flask(__name__)
    app.config.from_object("config.Config")
    from app.routes.home import home_bp
    from app.routes.reports import reports_bp
    from app.routes.settings import settings_bp
    app.register_blueprint(home_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(settings_bp)
    @app.errorhandler(403)
    def forbidden(error):
        from flask import render_template
        return render_template("error.html", code=403, message=getattr(error, "description", "User does not have permission to access.")), 403
    return app
