from flask import Blueprint, render_template, request, redirect, url_for, session, current_app, abort
import json

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        user_id = request.form.get("user_id", "").strip()
        with open(current_app.config["USERS_PATH"], "r", encoding="utf-8") as f:
            users = json.load(f)
        # Demo identity selector. No passwords are used in this sample.
        # Replace with corporate SSO/secure authentication before deployment.
        if user_id in users:
            session.clear()
            session["user_id"] = user_id
            return redirect(url_for("home.dashboard"))
        error = "User does not have permission to access."
    with open(current_app.config["USERS_PATH"], "r", encoding="utf-8") as f:
        users = json.load(f)
    return render_template("login.html", users=users, error=error)

@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
