from flask import Blueprint, render_template, current_app
import json
from app.auth.user_context import get_current_user
from app.services.file_service import available_dates

home_bp = Blueprint("home", __name__)

@home_bp.route("/")
@home_bp.route("/home")
def dashboard():
    user = get_current_user()
    with open(current_app.config["REPORT_REGISTRY_PATH"], "r", encoding="utf-8") as f:
        registry = json.load(f)
    reports = registry.get("reports", [])
    for report in reports:
        report["available_dates"] = available_dates(report, current_app.config["REPORT_DATA_ROOT"], registry.get("versions", ["Daily", "Flash", "Final"]))
    return render_template("home/dashboard.html", user=user, reports=reports)
