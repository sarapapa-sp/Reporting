from flask import Blueprint, render_template, request, jsonify, current_app
from pathlib import Path
import json
from app.auth.user_context import get_current_user
from app.auth.permissions import roles_required
from app.services.report_reader import load_report
from app.services.file_service import available_dates

reports_bp = Blueprint("reports", __name__)

@reports_bp.route("/reports")
def dashboard():
    user = get_current_user()
    with open(current_app.config["REPORT_REGISTRY_PATH"], "r", encoding="utf-8") as f:
        registry = json.load(f)
    return render_template(
        "reports/dashboard.html",
        user=user,
        reports=registry.get("reports", []),
        versions=registry.get("versions", ["Daily", "Flash", "Final"]),
        show_metadata=user.get("role") in ("admin", "pub_team")
    )

@reports_bp.route("/api/available-dates")
def available_dates_api():
    get_current_user()
    report_id = request.args.get("report", "").strip()
    with open(current_app.config["REPORT_REGISTRY_PATH"], "r", encoding="utf-8") as f:
        registry = json.load(f)
    report = next((item for item in registry.get("reports", []) if item.get("id") == report_id), None)
    if report is None:
        return jsonify({"dates": []})
    dates = available_dates(report, Path(current_app.config["REPORT_DATA_ROOT"]), registry.get("versions", ["Daily", "Flash", "Final"]))
    return jsonify({"dates": dates})


@reports_bp.route("/api/report")
def report_api():
    get_current_user()
    report_id = request.args.get("report", "").strip()
    business_date = request.args.get("date", "").strip()
    version = request.args.get("version", "").strip()
    try:
        result = load_report(
            report_id=report_id,
            business_date=business_date,
            version=version,
            registry_path=Path(current_app.config["REPORT_REGISTRY_PATH"]),
            mapping_path=Path(current_app.config["MAPPING_PATH"]),
            data_root=Path(current_app.config["REPORT_DATA_ROOT"]),
        )
    except ValueError as exc:
        return jsonify({"status": "error", "message": str(exc)}), 400
    return jsonify(result)

@reports_bp.route("/api/report/metadata")
@roles_required("admin", "pub_team")
def report_metadata_api():
    report_id = request.args.get("report", "").strip()
    business_date = request.args.get("date", "").strip()
    version = request.args.get("version", "").strip()
    result = load_report(
        report_id=report_id,
        business_date=business_date,
        version=version,
        registry_path=Path(current_app.config["REPORT_REGISTRY_PATH"]),
        mapping_path=Path(current_app.config["MAPPING_PATH"]),
        data_root=Path(current_app.config["REPORT_DATA_ROOT"]),
    )
    return jsonify({"metadata": result.get("metadata", [])})
