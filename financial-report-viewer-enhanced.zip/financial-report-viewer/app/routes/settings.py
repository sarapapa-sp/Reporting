from flask import Blueprint, render_template, request, redirect, url_for, current_app, flash
import json
from app.auth.permissions import roles_required
from app.auth.user_context import get_current_user

settings_bp = Blueprint("settings", __name__)

@settings_bp.route("/settings", methods=["GET", "POST"])
@roles_required("admin")
def user_management():
    with open(current_app.config["USERS_PATH"], "r", encoding="utf-8") as f:
        users = json.load(f)

    if request.method == "POST":
        user_id = request.form.get("user_id", "").strip()
        role = request.form.get("role", "").strip()
        if user_id not in users:
            flash("Unknown user ID.", "error")
        elif role not in ("admin", "pub_team", "user"):
            flash("Invalid role.", "error")
        else:
            users[user_id]["role"] = role
            with open(current_app.config["USERS_PATH"], "w", encoding="utf-8") as f:
                json.dump(users, f, indent=2)
            flash(f"Role updated for {user_id}.", "success")
        return redirect(url_for("settings.user_management"))

    return render_template("settings/user_management.html", user=get_current_user(), users=users)
