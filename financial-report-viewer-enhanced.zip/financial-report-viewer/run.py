"""Development entry point for the Financial Report Viewer."""
import os
from app import create_app

app = create_app()

if __name__ == "__main__":
    # Debug is opt-in so the app is not accidentally run in debug mode.
    debug = os.environ.get("FLASK_DEBUG", "0").lower() in {"1", "true", "yes"}
    app.run(host=os.environ.get("HOST", "127.0.0.1"),
            port=int(os.environ.get("PORT", "5000")),
            debug=debug)
