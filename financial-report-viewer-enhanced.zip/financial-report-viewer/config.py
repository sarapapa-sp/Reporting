from pathlib import Path
import os
BASE_DIR = Path(__file__).resolve().parent
class Config:
    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "change-this-demo-secret-before-deployment")
    MAPPING_PATH = BASE_DIR / "data" / "mapping.json"
    REPORT_REGISTRY_PATH = BASE_DIR / "data" / "report_registry.json"
    REPORT_DATA_ROOT = Path(os.environ.get("REPORT_DATA_ROOT", BASE_DIR / "BASE_DUMP")).resolve()
    USERS_PATH = BASE_DIR / "data" / "users.json"
    USER_ID_HEADER = os.environ.get("USER_ID_HEADER", "REMOTE_USER")
