# Financial Report Viewer

A read-only Flask application for browsing already-generated report JSON files. It does not run the report engine or generate reports.

## Report file structure

Configure `REPORT_DATA_ROOT` to the directory containing report folders. By default this is `BASE_DUMP/` inside the project.

```text
BASE_DUMP/
└── Revenue/                 # Report folder name from report_registry.json
    ├── daily/
    │   └── YYYY/MM/DD/*.json
    └── eom/
        ├── flash/YYYY/MM/DD/*.json
        └── final/YYYY/MM/DD/*.json
```

For Daily, files are read from `Report_name/daily/year/month/date/`. For Flash and Final, files are read from `Report_name/eom/flash/year/month/date/` and `Report_name/eom/final/year/month/date/` respectively. Section filename patterns are configured in `data/report_registry.json`; the first segment identifies the report folder and the final segment is the filename pattern.

Set a custom data root if needed:

```bash
# macOS/Linux
export REPORT_DATA_ROOT="/path/to/BASE_DUMP"

# Windows PowerShell
$env:REPORT_DATA_ROOT = "D:\\path\\to\\BASE_DUMP"
```

## Install and run

```bash
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python run.py
```

Open `http://127.0.0.1:5000`.

## Features

- Home dashboard discovers dates and versions from existing JSON files for each configured report.
- Report page has selectable dates, date availability chips, and a manual Refresh button.
- Each report section can be collapsed/expanded; hierarchical rows can also be collapsed/expanded.
- Normal page scrolling is used; tables only scroll horizontally when needed.
- Metadata is available only to `admin` and `pub_team` roles.
- Settings and role management are restricted to `admin`.

## User identity and roles

The app reads the user ID from the trusted identity header configured by `USER_ID_HEADER` (defaults to `REMOTE_USER`) and matches it against `data/users.json`. Sample IDs: `demo_admin`, `demo_pub`, and `demo_user`. This is not a login system; configure your trusted SSO/reverse proxy to set the header and prevent clients from spoofing it. For deployment, set a strong `FLASK_SECRET_KEY`.
