"""Lightweight verification for the GM Trend report package."""
from __future__ import annotations

import io
import unittest
from datetime import date
from zipfile import ZipFile
from xml.etree import ElementTree as ET

import pandas as pd

from gm_trend_charts import GMTrendCharts
from trend_report_export import generate_trend_report_excel

NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart',
      'd': 'http://schemas.openxmlformats.org/drawingml/2006/main'}


def mock_pivots():
    return pd.DataFrame({
        'report_name': ['Revenue', 'Revenue', 'Costs', 'Costs', 'Other'],
        'indicator': ['A', 'B', 'A', 'B', 'A'],
        '2026-11-04': [10, -1, 2, -4, 1],
        '2026-11-05': [14, 2, -1, 5, -2],
        '2026-11-06': [9, -3, 3, -2, 1],
        '2026-11-09': [18, -2, -8, 4, -3],
        '2026-11-10': [13, 4, -5, 2, 8],
    })


class GMReportTests(unittest.TestCase):
    def test_visuals(self):
        charts = GMTrendCharts(mock_pivots())
        heatmap = charts.create_heatmap(n_cobs=3, end_cob='2026-11-09')
        self.assertEqual(heatmap.data[0].x[0], '09 Nov 2026')
        self.assertEqual(heatmap.data[0].x[-1], '05 Nov 2026')
        line = charts.create_line_graph(indicators='A', n_cobs=2)
        self.assertEqual(line.data[0].x, ('09 Nov 2026', '10 Nov 2026'))
        self.assertEqual(line.data[0].line.color, '#636EFA')

    def test_generated_workbook(self):
        trends = pd.DataFrame({'report_name':['Revenue'], 'indicator':['A'],
                              'trend_score':[1.25], 'comment':['=danger']})
        captured = []
        def runner(**kwargs):
            captured.append(kwargs)
            return {'trends': trends, 'daily': mock_pivots(),
                    'mtd': mock_pivots(), 'ytd': mock_pivots(),
                    'trends_current_quarter': pd.DataFrame({'period':['Q4'], 'slope':[2.0]}),
                    'log_path':'/tmp/test.log'}

        filedata = generate_trend_report_excel(
            root_folder='/tmp/example', cob_date='2026-11-10',
            comparison_cobs=4, months_to_load=3,
            trend_period='current_quarter', runner=runner)
        self.assertEqual(len(captured), 1)
        self.assertEqual(captured[0]['n'], 4)
        self.assertEqual(captured[0]['trend_period'], 'current_quarter')
        with ZipFile(io.BytesIO(filedata)) as zipfile:
            workbook = ET.fromstring(zipfile.read('xl/workbook.xml'))
            names = [x.attrib['name'] for x in workbook.find('s:sheets',NS)]
            self.assertEqual(names[:4], ['Trend Analysis','P&L Heatmap','Trend Data','Trend Charts'])
            self.assertIn('trends_current_quarter', names)
            self.assertIn('mtd', names)
            self.assertIn('Export Parameters', names)
            self.assertIn('xl/charts/chart1.xml', zipfile.namelist())

            heat = ET.fromstring(zipfile.read('xl/worksheets/sheet2.xml'))
            dimensions = heat.find('s:cols', NS)
            self.assertIsNotNone(dimensions)
            # Numeric P&L cells are assigned explicit fills, not just conditional formats.
            row5 = heat.find("s:sheetData/s:row[@r='5']", NS)
            numeric_cells = [c for c in row5 if c.attrib['r'].startswith(('C','D','E','F'))]
            self.assertEqual(len(numeric_cells), 4)
            self.assertTrue(all('s' in c.attrib for c in numeric_cells))
            # COB-header rotation, and independently colored red/green values.
            styles = ET.fromstring(zipfile.read('xl/styles.xml'))
            alignments = [x.get('textRotation') for x in styles.findall('.//s:alignment', NS)]
            self.assertIn('90', alignments)
            self.assertGreaterEqual(len(styles.find('s:fills',NS)), 8)
            chart = zipfile.read('xl/charts/chart1.xml').decode()
            self.assertIn('636EFA', chart)
            self.assertIn('EF553B', chart)

    def test_invalid_period(self):
        with self.assertRaises(ValueError):
            generate_trend_report_excel('/tmp', date(2026,11,10), trend_period='week')


if __name__ == '__main__':
    unittest.main(verbosity=2)
