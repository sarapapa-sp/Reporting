# Global Markets Trend Dashboard — final enhancements

This package updates your **existing** `GMTrendCharts` class and adds a separate, on-demand **Save File** workflow for Excel exports.

## Contents

| File | Purpose |
|---|---|
| `gm_trend_charts.py` | Reusable Plotly heatmap/line-graph class + editable Excel generation |
| `trend_report_export.py` | Calls your repository's `run_trend_analysis()` and assembles the workbook |
| `streamlit_gm_trend_demo.py` | Streamlit dashboard with `Heatmap`, `Line Graphs`, and `Save File` tabs |
| `requirements_gm_trend.txt` | Python dependencies |
| `test_gm_trend.py` | Unit tests with a mock trend engine; no proprietary P&L required |

## IMPORTANT: required files from your existing GitHub repository

The new code **uses** your existing trend calculation module; it does not replace it. Install these files **into the same `Reporting/Trend/` folder** where the following files already exist:

- `run_trend_analysis.py`
- `Publication_Trendv2.py`

Their public source is:

- https://github.com/sarapapa-sp/Reporting/blob/main/Trend/run_trend_analysis.py
- https://github.com/sarapapa-sp/Reporting/blob/main/Trend/Publication_Trendv2.py

These two files are **not** duplicated in the ZIP so that you always use your current repository implementations.

## Installation and running

```bash
pip install -r requirements_gm_trend.txt
export GM_TREND_ROOT_FOLDER="/path/to/your/report/data"  # macOS/Linux, incl. JupyterHub
streamlit run streamlit_gm_trend_demo.py
```

On Windows PowerShell:

```powershell
$env:GM_TREND_ROOT_FOLDER="C:\\path\\to\\report\\data"
streamlit run streamlit_gm_trend_demo.py
```

Your data root should contain the expected year/month reporting files, such as
`2026/Report_data_Nov.xlsx`, as required by `Publication_Trendv2.py`.

Alternatively configure the Streamlit secret `GM_TREND_ROOT_FOLDER`, or call
`render_trend_dashboard(df_trend, root_folder="...")` directly from your own app.

The demonstration chart data is illustrative; **Save File does not use the demonstration data**.
It always invokes your real repository engine with the chosen parameters.

## Streamlit behavior

The charts use your pre-pivoted input DataFrame:

```
report_name | indicator | 2026-11-04 | 2026-11-05 | ...
```

Import and use in your current app:

```python
from streamlit_gm_trend_demo import render_trend_dashboard

render_trend_dashboard(df_trend, root_folder="/your/report/data")
```

Do not call `st.set_page_config()` twice. The `main()` demo function is the only place this file invokes it.

* **Heatmap** — latest COB on the left; red/neutral/green color scale.
* **Line Graphs** — chronological COB dates; one line per report, colored with the default Plotly qualitative palette. Multiple indicator selections are summed per report.
* **Save File** — separate form; selecting dates/parameters does NOT rerun analysis.
  - COB Date defaults to `getrecentcob()` (today - 4 Mon–Fri business days; no holiday calendar yet)
  - Comparison COBs: `5`
  - Months to Load: `3`
  - Trend Period: `n_business_days`; other options: `current_quarter`, `current_year`, `all`
  - Click **Generate Excel report** (calls your existing `run_trend_analysis()` **once**); then **Download Excel report**.

## Returned workbook

1. **Trend Analysis** (first sheet) — the exact `results['trends']` DataFrame, retaining source columns.
2. **P&L Heatmap** — latest COB first, fixed width **12** for COB columns, **90°** rotated COB headers, **11** diverging fill colors. Each numeric value is colored using a direct Excel cell fill (works even without Excel conditional-format evaluation). Empty P&L values are grey.
3. **Trend Data** — `results['daily']` numeric rows, chronologically ordered COBs.
4. **Trend Charts** — editable, Excel-native one-line-per-report chart using Plotly default category colors.
5. **Additional DataFrames** — includes `mtd`, `ytd`, `trends_<period>`, and quarter/year daily pivots when returned by the engine.
6. **Export Parameters** — provenance and selection info (COB date, n, months loaded, period, version, root, log path).

## The exact runner call

```python
results = run_trend_analysis(
    root_folder=ROOT_FOLDER,
    cob_date=selected_cob.strftime("%Y-%m-%d"),
    n=comparison_cobs,
    months_to_load=months_to_load,
    version="Daily",
    trend_period=trend_period,
)
```

The repository returns `results['trends']` (plural), **not** `results['trend']`.
The `n` parameter is the number of **distinct available COBs including as-of**.
The quarter/year trend modes may expand the data load automatically, according to the runner logic.

## Independent Python use

```python
from gm_trend_charts import GMTrendCharts
from trend_report_export import generate_trend_report_excel

charts = GMTrendCharts(df_trend)
plotly_heatmap = charts.create_heatmap(end_cob='2026-11-10', n_cobs=5)
plotly_lines = charts.create_line_graph(indicators=['A'], n_cobs=5)

xlsx_bytes = generate_trend_report_excel(
    root_folder=ROOT_FOLDER,
    cob_date='2026-11-10',
    comparison_cobs=5,
    months_to_load=3,
    trend_period='n_business_days',
)
with open('GM_Trend_Analysis_20261110.xlsx', 'wb') as f:
    f.write(xlsx_bytes)
```

For backward compatibility, `GMTrendCharts.export_trend_report_excel()` still
works directly on its input DataFrame, producing the three core sheets. If you
pass a `trends_df`, the Trend Analysis sheet becomes the first sheet.

## Verification

```bash
python test_gm_trend.py
```

Tests cover date ordering, Plotly colors, `run_trend_analysis()` argument wiring
(mocked), workbook sheet order, 90-degree Excel header style, individual colored
cell fills, Excel-native chart part, and a requested period. The tests use synthetic
values; you should also run one export against real source data in your environment.
