"""On-demand Excel report generation using the EXISTING GitHub trend engine.

Put this module beside run_trend_analysis.py and Publication_Trendv2.py in
Reporting/Trend. No trend calculations are reimplemented here.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
from datetime import date
from pathlib import Path
from typing import Any

import pandas as pd

from gm_trend_charts import GMTrendCharts

TREND_PERIODS = (
    "n_business_days", "current_quarter", "current_year", "all",
)


def generate_trend_report_excel(
    root_folder: str | Path,
    cob_date: str | date,
    comparison_cobs: int = 5,
    months_to_load: int = 3,
    trend_period: str = "n_business_days",
    *,
    version: str = "Daily",
    runner: Callable[..., Mapping[str, Any]] | None = None,
) -> bytes:
    """Run the live trend engine and build an editable multi-sheet XLSX.

    * First worksheet: results['trends'] (the complete source DataFrame).
    * P&L Heatmap: results['daily'] heatmap with latest COB at left.
    * Trend Data: results['daily'] original numeric observations.
    * Trend Charts: Excel-native lines, one per report (Plotly palette).
    * Additional worksheets: MTD, YTD, and period-specific DataFrames.

    `runner` exists for unit tests; in production the repository's
    `run_trend_analysis.run_trend_analysis` is called, exactly once.
    """
    if isinstance(comparison_cobs, bool) or not isinstance(comparison_cobs, int) or comparison_cobs < 1:
        raise ValueError("comparison_cobs must be a positive integer.")
    if isinstance(months_to_load, bool) or not isinstance(months_to_load, int) or months_to_load < 1:
        raise ValueError("months_to_load must be a positive integer.")
    if trend_period not in TREND_PERIODS:
        raise ValueError(f"trend_period must be one of: {', '.join(TREND_PERIODS)}")
    parsed_date = pd.to_datetime(cob_date, errors="coerce")
    if pd.isna(parsed_date):
        raise ValueError(f"Invalid COB date: {cob_date!r}")
    cob_text = pd.Timestamp(parsed_date).strftime('%Y-%m-%d')

    if runner is None:
        # Lazy import: dashboard charts can run in demo mode without the engine.
        try:
            from run_trend_analysis import run_trend_analysis
        except ImportError as exc:
            raise RuntimeError(
                "Could not import run_trend_analysis.py. Place these files in "
                "your repository Trend/ folder beside run_trend_analysis.py "
                "and Publication_Trendv2.py."
            ) from exc
        runner = run_trend_analysis

    results = runner(
        root_folder=str(root_folder),
        cob_date=cob_text,
        n=comparison_cobs,
        months_to_load=months_to_load,
        version=version,
        trend_period=trend_period,
    )
    if not isinstance(results, Mapping):
        raise ValueError("run_trend_analysis() must return a dictionary-like mapping.")
    trends = results.get('trends')  # singular is NOT a valid key in the repository
    daily = results.get('daily')
    if not isinstance(trends, pd.DataFrame):
        raise ValueError("The runner did not return a DataFrame at results['trends'].")
    if not isinstance(daily, pd.DataFrame):
        raise ValueError("The runner did not return a DataFrame at results['daily'].")

    extras = {
        key: frame for key, frame in results.items()
        if key not in ('trends', 'daily', 'log_path')
        and isinstance(frame, pd.DataFrame)
    }
    chart = GMTrendCharts(daily)
    selected_n_cobs = min(comparison_cobs, len(chart.date_columns))
    return chart.export_trend_report_excel(
        n_cobs=selected_n_cobs,
        end_cob=cob_text,
        pnl_measure=version,
        trends_df=trends,
        extra_frames=extras,
        export_parameters={
            'cob_date': cob_text,
            'comparison_cobs': comparison_cobs,
            'months_to_load': months_to_load,
            'trend_period': trend_period,
            'version': version,
            'root_folder': str(root_folder),
            'log_path': str(results.get('log_path', '')),
        },
    )
