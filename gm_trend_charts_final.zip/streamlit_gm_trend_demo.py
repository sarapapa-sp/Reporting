"""Streamlit GM Trends: preview charts + separate on-demand Save File tab.

Run in your repository's Trend/ folder:
    export GM_TREND_ROOT_FOLDER=/path/to/report_data
    streamlit run streamlit_gm_trend_demo.py

Replace sample_trend_data() with the existing DataFrame in your application.
"""
from __future__ import annotations

import os
from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

from gm_trend_charts import GMTrendCharts
from trend_report_export import TREND_PERIODS, generate_trend_report_excel


def getrecentcob() -> date:
    """Temporary default: today minus four Mon–Fri business days.

    Uses the server's local date. Holidays are not excluded.
    Replace with your approved market COB-calendar function when ready.
    """
    return (pd.Timestamp.today().normalize() - pd.offsets.BDay(4)).date()


def sample_trend_data() -> pd.DataFrame:
    """Demonstration data ONLY: replace with a real pre-pivoted DataFrame."""
    dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=18)
    df = pd.DataFrame({
        'report_name': ['Revenue', 'Revenue', 'Costs', 'Costs', 'Other'],
        'indicator': ['A', 'B', 'A', 'B', 'A'],
    })
    for i, cob in enumerate(dates):
        df[cob.strftime('%Y-%m-%d')] = [
            10 + (i % 6), -3 + (i % 5), -10 + (i % 4),
            4 + (i % 3), 6 + (i % 6),
        ]
    return df


def configured_root_folder() -> str:
    """Read your data path from Streamlit secrets or the environment."""
    # Secrets access may raise FileNotFoundError if the file is absent.
    try:
        secret = st.secrets.get('GM_TREND_ROOT_FOLDER', '')
    except Exception:  # Streamlit raises its own missing-secrets exception
        secret = ''
    return str(secret or os.environ.get('GM_TREND_ROOT_FOLDER', '')).strip()


def render_trend_dashboard(df_trend: pd.DataFrame, root_folder: str | None = None):
    """Render with any pre-pivoted report/indicator x COB DataFrame."""
    st.title('Global Markets | Trend Analysis')
    charts = GMTrendCharts(df_trend)

    col1, col2, col3, col4 = st.columns([2, 2, 1, 1.5])
    with col1:
        selected_reports = st.multiselect(
            'Reports', charts.reports, default=charts.reports, key='view_reports'
        )
    with col2:
        selected_indicators = st.multiselect(
            'Indicators', charts.indicators, default=charts.indicators,
            key='view_indicators'
        )
    with col3:
        n_cobs = st.number_input(
            'Previous COBs', min_value=1, max_value=len(charts.date_columns),
            value=min(5, len(charts.date_columns)), step=1, key='view_n_cobs'
        )
    with col4:
        selected_cob = st.date_input(
            'COB Date (as-of)', value=getrecentcob(), max_value=date.today(),
            format='DD/MM/YYYY', key='view_cob'
        )

    tab_heatmap, tab_lines, tab_save = st.tabs(
        ['Heatmap', 'Line Graphs', 'Save File']
    )

    with tab_heatmap:
        if not selected_reports or not selected_indicators:
            st.info('Select at least one report and indicator above.')
        else:
            try:
                available = charts.available_cobs(selected_cob)
                if not available:
                    st.warning('No historical COB data exists on or before the selected date.')
                else:
                    if available[-1] != selected_cob:
                        st.caption(f'Latest available COB: {available[-1]:%d %b %Y}')
                    fig = charts.create_heatmap(
                        reports=selected_reports, indicators=selected_indicators,
                        n_cobs=int(n_cobs), end_cob=selected_cob
                    )
                    st.plotly_chart(fig, use_container_width=True)
            except ValueError as exc:
                st.error(str(exc))

    with tab_lines:
        if not selected_reports or not selected_indicators:
            st.info('Select at least one report and indicator above.')
        else:
            try:
                fig = charts.create_line_graph(
                    reports=selected_reports, indicators=selected_indicators,
                    n_cobs=int(n_cobs), end_cob=selected_cob
                )
                st.caption('Each report is a separate line. Multiple selected indicators are summed per report.')
                st.plotly_chart(fig, use_container_width=True)
            except ValueError as exc:
                st.error(str(exc))

    with tab_save:
        st.subheader('Generate Excel Trend Report')
        st.caption('Independent from the chart filters. Calls run_trend_analysis() only on Generate.')
        with st.form('gm_trend_export_form'):
            export_cob = st.date_input(
                'COB Date', value=getrecentcob(),
                max_value=date.today(), format='DD/MM/YYYY', key='export_cob'
            )
            left, right = st.columns(2)
            with left:
                comparison_cobs = st.number_input(
                    'Comparison COBs', min_value=1, max_value=500, value=5,
                    step=1, key='export_comparison_cobs'
                )
            with right:
                months_to_load = st.number_input(
                    'Months to Load', min_value=1, max_value=36, value=3,
                    step=1, key='export_months_to_load'
                )
            period = st.selectbox(
                'Trend Period', options=TREND_PERIODS, index=0,
                format_func=lambda s: s.replace('_', ' ').title(),
                key='export_trend_period'
            )
            generate = st.form_submit_button('Generate Excel report', type='primary')

        if generate:
            # Discard previous downloads if a new generation fails.
            st.session_state.pop('gm_export_data', None)
            st.session_state.pop('gm_export_filename', None)
            configured_path = root_folder or configured_root_folder()
            if not configured_path:
                st.error(
                    'Set GM_TREND_ROOT_FOLDER to the root directory of your '
                    'year/month source files, or pass root_folder= to render_trend_dashboard().'
                )
            elif not Path(configured_path).is_dir():
                st.error(f'Data root folder does not exist: {configured_path}')
            else:
                with st.spinner('Running trend analysis and generating Excel workbook...'):
                    try:
                        payload = generate_trend_report_excel(
                            root_folder=configured_path,
                            cob_date=export_cob,
                            comparison_cobs=int(comparison_cobs),
                            months_to_load=int(months_to_load),
                            trend_period=period,
                        )
                    except Exception as exc:
                        st.error(f'Excel export failed: {exc}')
                    else:
                        filename = (
                            f'GM_Trend_Analysis_{export_cob:%Y%m%d}_'
                            f'{period}.xlsx'
                        )
                        st.session_state['gm_export_data'] = payload
                        st.session_state['gm_export_filename'] = filename
                        st.success('Excel workbook generated. Download it below.')

        if 'gm_export_data' in st.session_state:
            st.download_button(
                label='Download Excel report',
                data=st.session_state['gm_export_data'],
                file_name=st.session_state['gm_export_filename'],
                mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                key='gm_trend_excel_download',
            )


def main():
    st.set_page_config(page_title='Global Markets | Trend Analysis', layout='wide')
    st.info('Demo charts use illustrative P&L. Excel export uses your actual repository trend engine.')
    render_trend_dashboard(sample_trend_data())


if __name__ == '__main__':
    main()
