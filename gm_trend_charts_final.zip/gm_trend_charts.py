"""Plotly charts and Excel export for pre-pivoted Global Markets P&L data.

Input DataFrame structure:
    report_name | indicator | 2026-11-04 | 2026-11-05 | ...

The chart methods return Plotly go.Figure objects (no Streamlit dependency).
The Excel export returns editable multi-sheet XLSX bytes for Streamlit downloads.
Requires Python >= 3.10, pandas, numpy, plotly, openpyxl (for Excel only).
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date
from io import BytesIO

import numpy as np
import pandas as pd
import plotly.graph_objects as go


class GMTrendCharts:
    """Render and export trends from a pre-pivoted, COB-wide DataFrame."""

    REQUIRED_COLUMNS = ("report_name", "indicator")
    # Plotly's standard qualitative palette, reused in the native Excel chart.
    PLOTLY_COLORS = (
        "#636EFA", "#EF553B", "#00CC96", "#AB63FA", "#FFA15A",
        "#19D3F3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52",
    )

    def __init__(self, df: pd.DataFrame):
        if not isinstance(df, pd.DataFrame) or df.empty:
            raise ValueError("A non-empty pandas DataFrame is required.")

        missing = set(self.REQUIRED_COLUMNS) - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {sorted(missing)}")

        self.df = df.copy()
        for col in self.REQUIRED_COLUMNS:
            if self.df[col].isna().any() or self.df[col].astype(str).str.strip().eq("").any():
                raise ValueError(f"Column '{col}' contains missing/blank values.")
            self.df[col] = self.df[col].astype(str).str.strip()

        if self.df.duplicated(list(self.REQUIRED_COLUMNS)).any():
            raise ValueError("Each (report_name, indicator) combination must be unique.")

        raw_date_columns = [col for col in df.columns if col not in self.REQUIRED_COLUMNS]
        if not raw_date_columns:
            raise ValueError("At least one COB-date column is required.")

        date_pairs = []
        for col in raw_date_columns:
            parsed = pd.to_datetime(str(col), errors="coerce")
            if pd.isna(parsed):
                raise ValueError(f"Invalid COB-date column: {col!r}")
            date_pairs.append((pd.Timestamp(parsed).date(), col))

        if len({d for d, _ in date_pairs}) != len(date_pairs):
            raise ValueError("More than one column refers to the same COB date.")

        date_pairs.sort(key=lambda item: item[0])
        self.date_columns = [col for _, col in date_pairs]  # ascending for line graphs
        self.date_labels = {col: d.strftime("%d %b %Y") for d, col in date_pairs}
        self.column_dates = {col: d for d, col in date_pairs}

        raw = self.df[self.date_columns]
        numeric = raw.apply(pd.to_numeric, errors="coerce")
        non_numeric = raw.notna() & numeric.isna()
        if non_numeric.any().any():
            raise ValueError("COB-date columns must contain numeric P&L values or NaN.")
        if np.isinf(numeric.to_numpy(dtype=float)).any():
            raise ValueError("Infinite P&L values are not supported.")
        if numeric.isna().all().all():
            raise ValueError("All COB P&L values are missing.")
        self.df[self.date_columns] = numeric

    @property
    def reports(self) -> list[str]:
        return sorted(self.df["report_name"].unique().tolist())

    @property
    def indicators(self) -> list[str]:
        return sorted(self.df["indicator"].unique().tolist())

    @staticmethod
    def _parse_end_cob(end_cob: date | str | pd.Timestamp | None) -> date | None:
        if end_cob is None:
            return None
        try:
            parsed = pd.to_datetime(end_cob, errors="raise")
            if pd.isna(parsed):
                raise ValueError
            return pd.Timestamp(parsed).date()
        except (ValueError, TypeError, OverflowError) as exc:
            raise ValueError(f"Invalid end_cob date: {end_cob!r}") from exc

    def _filter(self, reports=None, indicators=None, n_cobs=None, end_cob=None):
        """Return filtered rows and available COB columns, oldest to newest.

        end_cob is an inclusive as-of cutoff. If there is no data *on* the
        chosen date, the latest available COB before it is used.
        """
        data = self.df.copy()
        for column, selected in (("report_name", reports), ("indicator", indicators)):
            if selected is not None:
                if isinstance(selected, str):
                    values = [selected]
                elif isinstance(selected, Sequence):
                    values = list(selected)
                else:
                    raise ValueError(f"{column} filter must be a string or sequence of strings.")
                if not values:
                    raise ValueError(f"{column} filter cannot be empty.")
                data = data[data[column].isin(values)]

        if data.empty:
            raise ValueError("No rows match the selected reports/indicators.")

        if n_cobs is not None and (
            isinstance(n_cobs, bool) or not isinstance(n_cobs, int) or n_cobs < 1
        ):
            raise ValueError("n_cobs must be a positive integer or None.")

        cutoff = self._parse_end_cob(end_cob)
        dates = [
            col for col in self.date_columns
            if cutoff is None or self.column_dates[col] <= cutoff
        ]
        if not dates:
            raise ValueError("No COB dates in the DataFrame on or before the selected date.")
        if n_cobs is not None:
            dates = dates[-n_cobs:]
        if data[dates].isna().all().all():
            raise ValueError("No P&L values available for the selected rows and dates.")
        return data, dates

    def available_cobs(self, end_cob=None) -> list[date]:
        """All available source COB dates up to an optional inclusive cutoff."""
        cutoff = self._parse_end_cob(end_cob)
        return [
            self.column_dates[col] for col in self.date_columns
            if cutoff is None or self.column_dates[col] <= cutoff
        ]

    def create_heatmap(
        self,
        reports: str | Sequence[str] | None = None,
        indicators: str | Sequence[str] | None = None,
        n_cobs: int | None = None,
        title: str = "Global Markets | P&L Heatmap",
        end_cob: date | str | pd.Timestamp | None = None,
    ) -> go.Figure:
        """One report/indicator per row; latest COB shown on the left."""
        data, dates_ascending = self._filter(reports, indicators, n_cobs, end_cob)
        dates = list(reversed(dates_ascending))
        data = data.sort_values(["report_name", "indicator"])
        z = data[dates].to_numpy(dtype=float)
        max_abs = max(1.0, float(np.nanmax(np.abs(z))))
        row_labels = (
            data["report_name"].astype(str) + " | " + data["indicator"].astype(str)
        ).tolist()
        cell_text = [
            [f"{v:,.2f}" if np.isfinite(v) else "" for v in row]
            for row in z
        ]
        x_labels = [self.date_labels[c] for c in dates]
        fig = go.Figure(
            go.Heatmap(
                x=x_labels,
                y=row_labels,
                z=z,
                text=cell_text,
                texttemplate="%{text}",
                textfont=dict(size=11),
                colorscale=[
                    [0.0, "#C0392B"],
                    [0.5, "#F5F5F5"],
                    [1.0, "#27AE60"],
                ],
                zmin=-max_abs,
                zmax=max_abs,
                xgap=2,
                ygap=2,
                colorbar=dict(title="P&L"),
                hovertemplate=(
                    "<b>%{y}</b><br>COB: %{x}<br>"
                    "P&L: %{z:,.2f}<extra></extra>"
                ),
            )
        )
        fig.update_layout(
            title=title,
            xaxis=dict(title="COB Date", type="category", side="top"),
            yaxis=dict(title="Report | Indicator", type="category", autorange="reversed", automargin=True),
            height=max(380, min(1800, 130 + len(data) * 37)),
            margin=dict(l=30, r=30, t=85, b=35),
            template="plotly_white",
        )
        return fig

    def create_line_graph(
        self,
        indicators: str | Sequence[str] | None = None,
        reports: str | Sequence[str] | None = None,
        n_cobs: int | None = None,
        title: str = "Global Markets | P&L Trend by Report",
        end_cob: date | str | pd.Timestamp | None = None,
    ) -> go.Figure:
        """One line per report; selected indicators are summed within each report.

        Line charts retain chronological date order (oldest on left).
        Missing values stay missing if all selected indicators are missing.
        """
        data, dates = self._filter(reports, indicators, n_cobs, end_cob)
        totals = data.groupby("report_name", sort=True)[dates].sum(min_count=1)
        x_labels = [self.date_labels[c] for c in dates]
        fig = go.Figure()
        for index, (report, row) in enumerate(totals.iterrows()):
            fig.add_trace(
                go.Scatter(
                    x=x_labels,
                    y=row.to_numpy(dtype=float),
                    mode="lines+markers",
                    name=str(report),
                    line=dict(width=2.5, color=self.PLOTLY_COLORS[index % len(self.PLOTLY_COLORS)]),
                    marker=dict(size=6, color=self.PLOTLY_COLORS[index % len(self.PLOTLY_COLORS)]),
                    connectgaps=False,
                    hovertemplate=(
                        f"<b>{report}</b><br>"
                        "COB: %{x}<br>P&L: %{y:,.2f}<extra></extra>"
                    ),
                )
            )
        fig.update_layout(
            title=title,
            xaxis=dict(title="COB Date", type="category", tickangle=-35),
            yaxis=dict(title="P&L", zeroline=True, zerolinecolor="#888888"),
            hovermode="x unified",
            legend=dict(title="Report", orientation="h", y=-0.27),
            height=480,
            margin=dict(l=50, r=20, t=70, b=110),
            template="plotly_white",
        )
        return fig

    def export_trend_report_excel(
        self,
        reports: str | Sequence[str] | None = None,
        indicators: str | Sequence[str] | None = None,
        n_cobs: int | None = None,
        end_cob: date | str | pd.Timestamp | None = None,
        pnl_measure: str = "Daily",
        *,
        trends_df: pd.DataFrame | None = None,
        extra_frames: dict[str, pd.DataFrame] | None = None,
        export_parameters: dict | None = None,
    ) -> bytes:
        """Build an editable Excel report and return its XLSX bytes.

        When `trends_df` is supplied (the runner's results['trends']), it is
        written as the FIRST worksheet, with its original columns intact.

        Subsequent sheets: P&L Heatmap, Trend Data, Trend Charts and optional
        other runner output DataFrames. The P&L heatmap uses explicit fills on
        EVERY numeric cell, so colors are visible even in viewers that do not
        calculate conditional formatting.
        """
        import re
        from datetime import datetime
        from openpyxl import Workbook
        from openpyxl.chart import LineChart, Reference
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter

        def excel_value(value):
            """Convert DataFrame scalars into safe Excel cell values."""
            if value is None:
                return None
            if isinstance(value, (pd.Timestamp, datetime)):
                ts = pd.Timestamp(value)
                if pd.isna(ts):
                    return None
                return ts.tz_localize(None).to_pydatetime() if ts.tzinfo else ts.to_pydatetime()
            if isinstance(value, np.generic):
                value = value.item()
            try:
                if pd.isna(value):
                    return None
            except (ValueError, TypeError):
                pass
            if isinstance(value, (list, tuple, dict, set)):
                value = str(value)
            if isinstance(value, (float, int)) and not isinstance(value, bool):
                if not np.isfinite(value):
                    return None
            return value

        def safe_write(ws, row, col, value):
            """Prevent formulas in source text from executing in Excel."""
            value = excel_value(value)
            cell = ws.cell(row, col, value)
            if isinstance(value, str) and value.startswith(("=", "+", "-", "@")):
                cell.data_type = "s"
            return cell

        data, dates_asc = self._filter(reports, indicators, n_cobs, end_cob)
        data = data.sort_values(["report_name", "indicator"])
        dates_desc = list(reversed(dates_asc))
        if len(data) + 5 > 1_048_576 or len(dates_asc) + 2 > 16_384:
            raise ValueError("Selected P&L data exceeds Excel worksheet limits.")
        effective_cob = self.column_dates[dates_asc[-1]]
        as_of = self._parse_end_cob(end_cob) or effective_cob

        wb = Workbook()
        wb.remove(wb.active)
        navy = "17365D"
        muted = "DDE7F1"
        pale = "F3F7FB"
        dark = "152D4A"
        white = "FFFFFF"
        number_format = '#,##0.00;[Red](#,##0.00);–'
        label_fill = PatternFill("solid", fgColor=navy)
        thin_rule = Border(bottom=Side(style="hair", color="D4DFEA"))

        def style_header(ws, header_row, last_col, *, rotated=False):
            for row in ws.iter_rows(min_row=header_row, max_row=header_row,
                                    min_col=1, max_col=last_col):
                for cell in row:
                    cell.fill = label_fill
                    cell.font = Font(name="Aptos", color=white, bold=True, size=10)
                    cell.alignment = Alignment(horizontal="center", vertical="center",
                                               text_rotation=90 if rotated and cell.column >= 3 else 0)
            ws.row_dimensions[header_row].height = 99 if rotated else 28

        def add_banner(ws, title):
            ws.sheet_view.showGridLines = False
            ws.cell(1, 1, title)
            ws['A1'].font = Font(name="Aptos Display", bold=True, size=15, color=dark)
            ws.row_dimensions[1].height = 30
            meta = [
                ("Selected COB", as_of), ("Effective COB", effective_cob),
                ("Measure", pnl_measure),
                ("Created", pd.Timestamp.now().strftime("%Y-%m-%d %H:%M")),
            ]
            for idx, (label, value) in enumerate(meta):
                col = 1 + idx * 2
                ws.cell(2, col, label).font = Font(bold=True, color=navy)
                ws.cell(2, col + 1, excel_value(value))
                if isinstance(value, date):
                    ws.cell(2, col + 1).number_format = "dd mmm yyyy"
            ws.row_dimensions[2].height = 23

        def write_dataframe_sheet(ws, frame, *, banner=False):
            if not isinstance(frame, pd.DataFrame):
                raise ValueError("Expected pandas DataFrame for Excel export.")
            if len(frame) + (5 if banner else 1) > 1_048_576:
                raise ValueError(f"DataFrame is too large for Excel: {ws.title}")
            header_row = 4 if banner else 1
            if banner:
                add_banner(ws, f"GLOBAL MARKETS | {ws.title.upper()}")
            if not len(frame.columns):
                safe_write(ws, header_row, 1, "No columns returned")
                return
            for c, column in enumerate(frame.columns, 1):
                safe_write(ws, header_row, c, str(column))
            style_header(ws, header_row, len(frame.columns))
            for r, row in enumerate(frame.itertuples(index=False, name=None), header_row + 1):
                for c, value in enumerate(row, 1):
                    cell = safe_write(ws, r, c, value)
                    if isinstance(cell.value, (float, int)) and not isinstance(cell.value, bool):
                        cell.number_format = number_format
                    elif isinstance(cell.value, (datetime, date)):
                        cell.number_format = "dd mmm yyyy"
                    if r % 2 == 0:
                        cell.fill = PatternFill('solid', fgColor=pale)
            ws.freeze_panes = f"C{header_row + 1}" if len(frame.columns) >= 3 else f"A{header_row + 1}"
            if len(frame):
                ws.auto_filter.ref = f"A{header_row}:{get_column_letter(len(frame.columns))}{header_row + len(frame)}"
            for c, column in enumerate(frame.columns, 1):
                width = min(31, max(13, len(str(column)) + 3))
                ws.column_dimensions[get_column_letter(c)].width = width

        # Main trend calculation is the FIRST sheet, as requested.
        if trends_df is not None:
            main = wb.create_sheet("Trend Analysis")
            write_dataframe_sheet(main, trends_df)

        ws_heatmap = wb.create_sheet("P&L Heatmap")
        ws_data = wb.create_sheet("Trend Data")
        ws_chart = wb.create_sheet("Trend Charts")
        for ws, title in (
            (ws_heatmap, "GLOBAL MARKETS | P&L HEATMAP"),
            (ws_data, "GLOBAL MARKETS | TREND DATA"),
            (ws_chart, "GLOBAL MARKETS | TREND CHARTS"),
        ):
            add_banner(ws, title)

        # Excel heatmap - fixed-width COB columns, vertical date headers.
        headers = ["Report Name", "Indicator", *[self.date_labels[c] for c in dates_desc]]
        for col, label in enumerate(headers, 1):
            safe_write(ws_heatmap, 4, col, label)
        style_header(ws_heatmap, 4, len(headers), rotated=True)
        ws_heatmap.column_dimensions['A'].width = 26
        ws_heatmap.column_dimensions['B'].width = 22
        for col in range(3, len(headers) + 1):
            ws_heatmap.column_dimensions[get_column_letter(col)].width = 12
        ws_heatmap.freeze_panes = "C5"
        ws_heatmap.auto_filter.ref = f"A4:{get_column_letter(len(headers))}{4 + len(data)}"

        values = data[dates_desc].to_numpy(dtype=float)
        finite = values[np.isfinite(values)]
        scale = max(1.0, float(np.max(np.abs(finite)))) if len(finite) else 1.0
        # Eleven red / neutral / green shade stops, fully applied as cell fills.
        color_stops = (
            "9E1A26", "BD3440", "D65D63", "E78C8A", "F7CBC8",
            "F6F8FA", "D7EEE5", "A9DEC8", "75C7A4", "39AB7E", "167C55",
        )
        fill_cache = {c: PatternFill("solid", fgColor=c) for c in (*color_stops, "EBF0F4")}
        for rownum, (_, record) in enumerate(data.iterrows(), 5):
            for colnum, key in ((1, "report_name"), (2, "indicator")):
                cell = safe_write(ws_heatmap, rownum, colnum, record[key])
                cell.font = Font(name="Aptos", color=dark, size=10)
                if rownum % 2 == 0:
                    cell.fill = PatternFill('solid', fgColor=pale)
            for colnum, cob_col in enumerate(dates_desc, 3):
                val = record[cob_col]
                cell = safe_write(ws_heatmap, rownum, colnum,
                                  float(val) if pd.notna(val) else None)
                cell.number_format = number_format
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.border = thin_rule
                if pd.isna(val):
                    cell.fill = fill_cache['EBF0F4']
                else:
                    normalized = max(-1.0, min(1.0, float(val) / scale))
                    idx = min(10, max(0, round((normalized + 1) * 5)))
                    cell.fill = fill_cache[color_stops[idx]]
            ws_heatmap.row_dimensions[rownum].height = 19

        # Underlying P&L observations stay chronological for chart formulas.
        raw_headers = ["Report Name", "Indicator", *[self.date_labels[c] for c in dates_asc]]
        for col, label in enumerate(raw_headers, 1):
            safe_write(ws_data, 4, col, label)
        style_header(ws_data, 4, len(raw_headers))
        for rownum, (_, record) in enumerate(data.iterrows(), 5):
            for colnum, key in ((1, "report_name"), (2, "indicator")):
                safe_write(ws_data, rownum, colnum, record[key])
            for colnum, cob_col in enumerate(dates_asc, 3):
                val = record[cob_col]
                cell = safe_write(ws_data, rownum, colnum,
                                  float(val) if pd.notna(val) else None)
                cell.number_format = number_format
                if rownum % 2 == 0:
                    cell.fill = PatternFill('solid', fgColor=pale)
        ws_data.freeze_panes = 'C5'
        ws_data.auto_filter.ref = f"A4:{get_column_letter(len(raw_headers))}{4 + len(data)}"
        ws_data.column_dimensions['A'].width = 26
        ws_data.column_dimensions['B'].width = 22
        for c in range(3, len(raw_headers) + 1):
            ws_data.column_dimensions[get_column_letter(c)].width = 15

        # Excel-native line chart with Plotly categorical palette and one line/report.
        totals = data.groupby('report_name', sort=True)[dates_asc].sum(min_count=1)
        names = list(totals.index)
        for col, label in enumerate(['COB Date', *names], 1):
            safe_write(ws_chart, 5, col, label)
        style_header(ws_chart, 5, len(names) + 1)
        for rownum, cob_col in enumerate(dates_asc, 6):
            safe_write(ws_chart, rownum, 1, self.column_dates[cob_col]).number_format = 'dd mmm yyyy'
            for colnum, report in enumerate(names, 2):
                value = totals.loc[report, cob_col]
                cell = safe_write(ws_chart, rownum, colnum,
                                  float(value) if pd.notna(value) else None)
                cell.number_format = number_format
        ws_chart.freeze_panes = 'B6'
        ws_chart.auto_filter.ref = f"A5:{get_column_letter(len(names)+1)}{5+len(dates_asc)}"
        ws_chart.column_dimensions['A'].width = 19
        for col in range(2, len(names) + 2):
            ws_chart.column_dimensions[get_column_letter(col)].width = 17

        chart = LineChart()
        chart.title = f"{pnl_measure} P&L Trend by Report"
        chart.style = 13
        chart.y_axis.title = "P&L"
        chart.x_axis.title = "COB Date"
        chart.height = 12.5
        chart.width = 24
        chart.display_blanks = 'gap'
        for colnum in range(2, len(names) + 2):
            chart.add_data(Reference(ws_chart, min_col=colnum, min_row=5,
                                     max_row=5 + len(dates_asc)), titles_from_data=True)
            series = chart.series[-1]
            color = self.PLOTLY_COLORS[(colnum - 2) % len(self.PLOTLY_COLORS)].lstrip('#')
            series.graphicalProperties.line.solidFill = color
            series.graphicalProperties.line.width = 26000  # EMUs; ~2pt
            series.marker.symbol = 'circle'
            series.marker.size = 5
            series.marker.graphicalProperties.solidFill = color
            series.marker.graphicalProperties.line.solidFill = color
            series.smooth = False
        chart.set_categories(Reference(ws_chart, min_col=1, min_row=6,
                                       max_row=5 + len(dates_asc)))
        ws_chart.add_chart(chart, f"A{len(dates_asc) + 9}")

        # Preserve any additional runner DataFrames (MTD/YTD/period variants).
        used_names = set(wb.sheetnames)
        for key, frame in (extra_frames or {}).items():
            if not isinstance(frame, pd.DataFrame):
                continue
            candidate = re.sub(r'[\\/*?:\[\]]', '_', str(key))[:31] or 'Additional Data'
            sheet_name = candidate
            index = 2
            while sheet_name in used_names:
                suffix = f'_{index}'
                sheet_name = candidate[:31 - len(suffix)] + suffix
                index += 1
            ws = wb.create_sheet(sheet_name)
            used_names.add(sheet_name)
            write_dataframe_sheet(ws, frame)

        # A compact audit sheet records the selected export parameters.
        if export_parameters:
            ws = wb.create_sheet('Export Parameters')
            ws.sheet_view.showGridLines = False
            ws.append(['Parameter', 'Value'])
            style_header(ws, 1, 2)
            for key, value in export_parameters.items():
                ws.append([str(key), excel_value(value)])
            ws.column_dimensions['A'].width = 26
            ws.column_dimensions['B'].width = 56
            ws.freeze_panes = 'A2'

        buffer = BytesIO()
        wb.save(buffer)
        return buffer.getvalue()
