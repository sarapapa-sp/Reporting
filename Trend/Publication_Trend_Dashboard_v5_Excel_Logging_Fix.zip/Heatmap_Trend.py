"""Heatmap and line chart utilities matching the original Heatmap_Trend.py data contract."""
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.colors import qualitative

COLORS=[[0,'#9b2226'],[.2,'#e76f51'],[.4,'#f4a261'],[.5,'#f8f9fa'],[.6,'#b7e4c7'],[.8,'#52b788'],[1,'#1b4332']]

def generate_heatmap(df,report_name='All Reports',n_cobs=None,title='Global Markets P&L Heatmap'):
    keys=['report_name','indicator']
    date_cols=sorted((c for c in df.columns if c not in keys),key=lambda x:pd.Timestamp(x),reverse=True)
    if n_cobs:date_cols=date_cols[:int(n_cobs)]
    data=df if report_name=='All Reports' else df[df['report_name']==report_name]
    if data.empty or not date_cols:raise ValueError('No data for selected heatmap')
    data=data.sort_values(keys)
    values=data[date_cols].apply(pd.to_numeric,errors='coerce').to_numpy(dtype=float)
    limit=max(1,float(np.nanmax(np.abs(values)))) if np.isfinite(values).any() else 1
    fig=go.Figure(go.Heatmap(z=values,x=[pd.Timestamp(x).strftime('%d %b %Y') for x in date_cols],
        y=(data['report_name'].astype(str)+' | '+data['indicator'].astype(str)).tolist(),
        text=np.where(np.isfinite(values),np.round(values,2).astype(str),''),texttemplate='%{text}',
        colorscale=COLORS,zmin=-limit,zmax=limit,xgap=2,ygap=2,
        colorbar=dict(title='mEUR'),hovertemplate='%{y}<br>%{x}<br>%{z:,.3f} mEUR<extra></extra>'))
    fig.update_layout(title=title,template='plotly_white',height=max(420,min(1500,130+len(data)*38)),
                      xaxis=dict(side='top',type='category'),
                      yaxis=dict(autorange='reversed',automargin=True))
    return fig

def generate_line_graph(df,report_name,indicators=None,n_cobs=None):
    keys=['report_name','indicator']
    date_cols=sorted((c for c in df.columns if c not in keys),key=lambda x:pd.Timestamp(x),reverse=True)
    if n_cobs:date_cols=date_cols[:int(n_cobs)]
    data=df if report_name=='All Reports' else df[df['report_name']==report_name]
    if indicators:data=data[data['indicator'].isin(indicators)]
    fig=go.Figure()
    for i,(_,r) in enumerate(data.sort_values(keys).iterrows()):
        fig.add_trace(go.Scatter(x=date_cols,y=[r[c] for c in date_cols],mode='lines+markers',
          name=f'{r.report_name} | {r.indicator}',line=dict(color=qualitative.Plotly[i%len(qualitative.Plotly)])))
    fig.update_layout(template='plotly_white',xaxis_title='COB date',yaxis_title='Daily P&L (mEUR)',hovermode='x unified')
    return fig

def history_to_pivot(history,as_of_date):
    df=history[history['cob_date']<=pd.Timestamp(as_of_date)].copy()
    df['cob_date']=df['cob_date'].dt.strftime('%Y-%m-%d')
    pivot=df.assign(daily=df['daily']/1000).pivot(index=['report_name','indicator'],columns='cob_date',values='daily').reset_index()
    dates=sorted((c for c in pivot.columns if c not in ('report_name','indicator')),reverse=True)
    return pivot[['report_name','indicator']+dates]


def generate_report_line_graph(df,n_cobs=None):
    """One line per report, summing the selected indicators for each COB."""
    keys=['report_name','indicator']
    dates=sorted((c for c in df.columns if c not in keys),key=pd.Timestamp,reverse=True)
    if n_cobs:dates=dates[:int(n_cobs)]
    dates=list(reversed(dates))  # plot chronological left to right
    grouped=df.groupby('report_name',as_index=False)[dates].sum(min_count=1)
    fig=go.Figure()
    for i,(_,r) in enumerate(grouped.iterrows()):
        fig.add_trace(go.Scatter(x=dates,y=[r[d] for d in dates],mode='lines+markers',
            name=str(r['report_name']),line=dict(color=qualitative.Plotly[i%len(qualitative.Plotly)])))
    fig.update_layout(title='Daily P&L by Report',template='plotly_white',
        xaxis_title='COB date',yaxis_title='Daily P&L (mEUR)',hovermode='x unified')
    return fig
