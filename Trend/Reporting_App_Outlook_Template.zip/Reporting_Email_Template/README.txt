OUTLOOK HTML TEMPLATE

1. Replace each images/*.png with your real screenshot, keeping the filename.
2. The HTML uses fixed width attributes and inline styles for Outlook.
3. Replace {{PUBLICATION_DASHBOARD_URL}} and {{REPORTING_REVIEW_URL}} with real HTTPS URLs.
4. Open HTML in a browser to preview. Copy/paste into Outlook may not preserve local images; for dependable delivery, insert screenshots into the Outlook message itself or host images on accessible HTTPS URLs and update src.
5. If you insert an image directly into Outlook, set its width to the corresponding tag width: 230px for the three screens, 300px override, 680px trends, 320px access.
6. Outlook may still change colors in dark mode; solid bgcolor attributes and inline colors reduce differences.
