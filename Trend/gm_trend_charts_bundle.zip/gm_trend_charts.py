"""Reusable Plotly charts for pre-pivoted Global Markets P&L data.

Expected columns:
    report_name | indicator | YYYY-MM-DD | YYYY-MM-DD | ...

Both public chart methods return plotly.graph_objects.Figure and make no
Streamlit calls. Requires pandas, numpy, plotly (Python >= 3.10).
"""

from collections.abc import Sequence

import numpy as np
import pandas as pd
import plotly.graph_objects as go


class GMTrendCharts:
    """Build heatmaps and report-wise line graphs from a COB-wide DataFrame."""

    REQUIRED_COLUMNS = ("report_name", "indicator")

    def __init__(self, df: pd.DataFrame):
        if not isinstance(df, pd.DataFrame) or df.empty:
            raise ValueError("A non-empty pandas DataFrame is required.")

        missing = set(self.REQUIRED_COLUMNS) - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {sorted(missing)}")

        self.df = df.copy()
        for col in self.REQUIRED_COLUMNS:
            if self.df[col].isna().any() or self.df[col].astype(str).str.strip().eq("").any():
                raise ValueError(f"Column '{col}' contains missing/blank values.")
            self.df[col] = self.df[col].astype(str).str.strip()

        if self.df.duplicated(list(self.REQUIRED_COLUMNS)).any():
            raise ValueError("Each (report_name, indicator) combination must be unique.")

        raw_date_columns = [col for col in df.columns if col not in self.REQUIRED_COLUMNS]
        if not raw_date_columns:
            raise ValueError("At least one COB-date column is required.")

        date_pairs = []
        for col in raw_date_columns:
            parsed = pd.to_datetime(str(col), errors="coerce")
            if pd.isna(parsed):
                raise ValueError(f"Invalid COB-date column: {col!r}")
            date_pairs.append((pd.Timestamp(parsed).normalize(), col))

        if len({d for d, _ in date_pairs}) != len(date_pairs):
            raise ValueError("More than one column refers to the same COB date.")

        date_pairs.sort(key=lambda item: item[0])
        self.date_columns = [col for _, col in date_pairs]
        self.date_labels = {col: date.strftime("%d %b %Y") for date, col in date_pairs}

        raw = self.df[self.date_columns]
        numeric = raw.apply(pd.to_numeric, errors="coerce")
        non_numeric = raw.notna() & numeric.isna()
        if non_numeric.any().any():
            raise ValueError("COB-date columns must contain numeric P&L values or NaN.")
        if np.isinf(numeric.to_numpy(dtype=float)).any():
            raise ValueError("Infinite P&L values are not supported.")
        if numeric.isna().all().all():
            raise ValueError("All COB P&L values are missing.")
        self.df[self.date_columns] = numeric

    @property
    def reports(self) -> list[str]:
        return sorted(self.df["report_name"].unique().tolist())

    @property
    def indicators(self) -> list[str]:
        return sorted(self.df["indicator"].unique().tolist())

    def _filter(self, reports=None, indicators=None, n_cobs=None):
        data = self.df.copy()
        for column, selected in (("report_name", reports), ("indicator", indicators)):
            if selected is not None:
                if isinstance(selected, str):
                    values = [selected]
                elif isinstance(selected, Sequence):
                    values = list(selected)
                else:
                    raise ValueError(f"{column} filter must be a string or sequence of strings.")
                if not values:
                    raise ValueError(f"{column} filter cannot be empty.")
                data = data[data[column].isin(values)]

        if data.empty:
            raise ValueError("No rows match the selected reports/indicators.")

        if n_cobs is not None:
            if isinstance(n_cobs, bool) or not isinstance(n_cobs, int) or n_cobs < 1:
                raise ValueError("n_cobs must be a positive integer or None.")
            dates = self.date_columns[-n_cobs:]
        else:
            dates = self.date_columns

        if data[dates].isna().all().all():
            raise ValueError("No P&L values available for the selected rows and dates.")

        return data, dates

    def create_heatmap(
        self,
        reports: str | Sequence[str] | None = None,
        indicators: str | Sequence[str] | None = None,
        n_cobs: int | None = None,
        title: str = "Global Markets | P&L Heatmap",
    ) -> go.Figure:
        """One row per report + indicator, one column per COB date."""
        data, dates = self._filter(reports, indicators, n_cobs)
        data = data.sort_values(["report_name", "indicator"])
        z = data[dates].to_numpy(dtype=float)
        max_abs = max(1.0, float(np.nanmax(np.abs(z))))
        row_labels = (
            data["report_name"].astype(str) + " | " + data["indicator"].astype(str)
        ).tolist()
        cell_text = [
            [f"{v:,.2f}" if np.isfinite(v) else "" for v in row]
            for row in z
        ]
        x_labels = [self.date_labels[c] for c in dates]

        fig = go.Figure(
            go.Heatmap(
                x=x_labels,
                y=row_labels,
                z=z,
                text=cell_text,
                texttemplate="%{text}",
                textfont=dict(size=11),
                colorscale=[
                    [0.0, "#C0392B"],
                    [0.5, "#F5F5F5"],
                    [1.0, "#27AE60"],
                ],
                zmin=-max_abs,
                zmax=max_abs,
                xgap=2,
                ygap=2,
                colorbar=dict(title="P&L"),
                hovertemplate=(
                    "<b>%{y}</b><br>COB: %{x}<br>"
                    "P&L: %{z:,.2f}<extra></extra>"
                ),
            )
        )
        fig.update_layout(
            title=title,
            xaxis=dict(title="COB Date", type="category", side="top"),
            yaxis=dict(title="Report | Indicator", type="category", autorange="reversed", automargin=True),
            height=max(380, min(1800, 130 + len(data) * 37)),
            margin=dict(l=30, r=30, t=85, b=35),
            template="plotly_white",
        )
        return fig

    def create_line_graph(
        self,
        indicators: str | Sequence[str] | None = None,
        reports: str | Sequence[str] | None = None,
        n_cobs: int | None = None,
        title: str = "Global Markets | P&L Trend by Report",
    ) -> go.Figure:
        """One line per report, summing P&L across selected indicators.

        Examples:
        - indicators="A": plot the P&L of indicator A for every report.
        - indicators=["A", "B"]: sum indicators A+B within each report.
        - indicators=None: sum all indicators within each report.

        A missing value remains missing if every included indicator is missing
        for that report/date (no silent conversion to zero).
        """
        data, dates = self._filter(reports, indicators, n_cobs)
        report_totals = data.groupby("report_name", sort=True)[dates].sum(min_count=1)
        x_labels = [self.date_labels[c] for c in dates]

        fig = go.Figure()
        for report, row in report_totals.iterrows():
            fig.add_trace(
                go.Scatter(
                    x=x_labels,
                    y=row.to_numpy(dtype=float),
                    mode="lines+markers",
                    name=str(report),
                    line=dict(width=2.5),
                    marker=dict(size=6),
                    connectgaps=False,
                    hovertemplate=(
                        f"<b>{report}</b><br>"
                        "COB: %{x}<br>P&L: %{y:,.2f}<extra></extra>"
                    ),
                )
            )

        fig.update_layout(
            title=title,
            xaxis=dict(title="COB Date", type="category", tickangle=-35),
            yaxis=dict(title="P&L", zeroline=True, zerolinecolor="#888888"),
            hovermode="x unified",
            legend=dict(title="Report", orientation="h", y=-0.27),
            height=480,
            margin=dict(l=50, r=20, t=70, b=110),
            template="plotly_white",
        )
        return fig
