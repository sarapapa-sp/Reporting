"""Example Streamlit integration. Run: streamlit run streamlit_gm_trend_demo.py"""

import pandas as pd
import streamlit as st

from gm_trend_charts import GMTrendCharts

st.set_page_config(page_title="GM Trend Analysis", layout="wide")
st.title("Global Markets | Trend Analysis")

# Replace this sample DataFrame with your class's pre-pivoted P&L output.
df_trend = pd.DataFrame({
    "report_name": ["Revenue", "Revenue", "Costs", "Costs", "Other"],
    "indicator": ["A", "B", "A", "B", "A"],
    "2026-11-04": [10, -1, -10, 4, 8],
    "2026-11-05": [14, 2, -4, 7, 10],
    "2026-11-06": [9, -3, 5, -2, 7],
    "2026-11-09": [18, -2, -8, 9, 11],
})

try:
    charts = GMTrendCharts(df_trend)

    left, middle, right = st.columns([2, 2, 1])
    with left:
        selected_reports = st.multiselect(
            "Reports", charts.reports, default=charts.reports,
        )
    with middle:
        selected_indicators = st.multiselect(
            "Indicators (applies to both charts)", charts.indicators,
            default=charts.indicators,
        )
    with right:
        n_cobs = st.number_input(
            "Previous COBs", min_value=1,
            max_value=len(charts.date_columns),
            value=min(5, len(charts.date_columns)), step=1,
        )

    if not selected_reports or not selected_indicators:
        st.info("Select at least one report and indicator.")
        st.stop()

    tab1, tab2 = st.tabs(["Heatmap", "Line Graphs"])
    with tab1:
        heatmap_fig = charts.create_heatmap(
            reports=selected_reports,
            indicators=selected_indicators,
            n_cobs=int(n_cobs),
        )
        st.plotly_chart(heatmap_fig, use_container_width=True)

    with tab2:
        line_fig = charts.create_line_graph(
            reports=selected_reports,
            indicators=selected_indicators,
            n_cobs=int(n_cobs),
        )
        st.caption("Each line is a report. Multiple selected indicators are summed within that report.")
        st.plotly_chart(line_fig, use_container_width=True)

except ValueError as exc:
    st.error(str(exc))
