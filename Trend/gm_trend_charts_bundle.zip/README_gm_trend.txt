GLOBAL MARKETS TREND CHARTS

Files:
- gm_trend_charts.py: GMTrendCharts class
- streamlit_gm_trend_demo.py: demo Streamlit app
- requirements_gm_trend.txt: dependencies

To run:
  pip install -r requirements_gm_trend.txt
  streamlit run streamlit_gm_trend_demo.py

DataFrame input:
  report_name | indicator | YYYY-MM-DD | YYYY-MM-DD | ...

Methods:
  GMTrendCharts(df).create_heatmap(reports=None, indicators=None, n_cobs=None)
  GMTrendCharts(df).create_line_graph(indicators=None, reports=None, n_cobs=None)

Both methods return plotly.graph_objects.Figure. The line graph shows one line per report; multiple selected indicators are summed for each report and COB.
