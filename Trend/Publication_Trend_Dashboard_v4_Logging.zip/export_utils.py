from io import BytesIO
import pandas as pd

MONETARY_COLUMNS={'daily','previous_month_daily','previous_month_change'}
MONETARY_SUFFIXES=('_avg','_std','_min','_max','_slope','_change')

def convert_to_meur(frame):
    out=frame.copy()
    for col in out.columns:
        if (col in MONETARY_COLUMNS or col.endswith(MONETARY_SUFFIXES)) and pd.api.types.is_numeric_dtype(out[col]):
            out[col]=out[col]/1000.0
    return out

def make_excel(result):
    output=BytesIO()
    with pd.ExcelWriter(output,engine='openpyxl') as writer:
        for key,sheet in [('trend','Trend')]:
            df=convert_to_meur(result[key]).drop(columns=['mtd','ytd'],errors='ignore')
            first=['cob_date','report_name','indicator','daily']
            df=df[[c for c in first if c in df.columns]+[c for c in df.columns if c not in first]]
            for c in df.columns:
                if c=='cob_date' or c.endswith('_cob') or c.endswith('_start') or c.endswith('_end'):
                    df[c]=pd.to_datetime(df[c],errors='coerce').dt.strftime('%Y-%m-%d').fillna('')
            df.to_excel(writer,index=False,sheet_name=sheet)
            ws=writer.sheets[sheet];ws.freeze_panes='D2';ws.auto_filter.ref=ws.dimensions
            for column in ws.columns:
                ws.column_dimensions[column[0].column_letter].width=25 if column[0].value in ('report_name','indicator') else 16
        if 'history' in result:
            from Heatmap_Trend import history_to_pivot
            hist=result['history']
            pivot=history_to_pivot(hist,hist['cob_date'].max())
            date_cols=sorted((c for c in pivot.columns if c not in ('report_name','indicator')),reverse=True)
            pivot=pivot[['report_name','indicator']+date_cols]
            pivot.to_excel(writer,index=False,sheet_name='Heatmap Data')
            from openpyxl.styles import Alignment,PatternFill,Font
            from openpyxl.formatting.rule import ColorScaleRule
            ws=writer.sheets['Heatmap Data']
            ws.freeze_panes='C2'
            for col in ws.iter_cols(min_col=3):
                ws.column_dimensions[col[0].column_letter].width=10
                col[0].alignment=Alignment(textRotation=90,horizontal='center',vertical='bottom')
            ws.row_dimensions[1].height=95
            for cell in ws[1]:
                cell.fill=PatternFill('solid',fgColor='17365D')
                cell.font=Font(bold=True,color='FFFFFF')
            ws.column_dimensions['A'].width=27
            ws.column_dimensions['B'].width=20
            if ws.max_row>1 and ws.max_column>2:
                ws.conditional_formatting.add(f'C2:{ws.cell(ws.max_row,ws.max_column).coordinate}',
                    ColorScaleRule(start_type='min',start_color='9C1C24',mid_type='percentile',mid_value=50,mid_color='FFFDF6',end_type='max',end_color='137547'))
    return output.getvalue()
