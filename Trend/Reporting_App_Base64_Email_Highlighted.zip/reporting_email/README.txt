1. Place six images in screenshots/ using the names figures.png, consistency.png,
   trend_screen.png, override.png, trend_analysis.png, access.png.
2. Update URLS in build_email.py with your internal application URLs.
3. Run: python build_email.py
4. Use Reporting_App_Ready_To_Send.html as your email's HTML body.

Note: Outlook desktop often does not render data:image/...;base64 images.
For reliable delivery to Outlook, send images as inline MIME attachments with
Content-ID references (CID) rather than data URIs.
