"""Populate the HTML template with Base64 screenshots and application URLs.

Run: python build_email.py
Installations: Python standard library only.
"""
from pathlib import Path
import base64
import html
import re

HERE = Path(__file__).resolve().parent
TEMPLATE = HERE / 'Reporting_App_Base64_Template.html'
OUTPUT = HERE / 'Reporting_App_Ready_To_Send.html'

# Change filenames to match your screenshots. PNG and JPEG are supported.
IMAGES = {
    'FIGURES': HERE / 'screenshots' / 'figures.png',
    'CONSISTENCY': HERE / 'screenshots' / 'consistency.png',
    'TREND_SCREEN': HERE / 'screenshots' / 'trend_screen.png',
    'OVERRIDE': HERE / 'screenshots' / 'override.png',
    'TREND_ANALYSIS': HERE / 'screenshots' / 'trend_analysis.png',
    'ACCESS': HERE / 'screenshots' / 'access.png',
}
URLS = {
    'PUBLICATION_DASHBOARD_URL': 'https://replace-with-your-publication-dashboard-url',
    'REPORTING_REVIEW_URL': 'https://replace-with-your-reporting-review-url',
}

def image_to_base64(path: Path) -> str:
    """Return only the Base64 data (without data:image/...;base64, prefix)."""
    return base64.b64encode(path.read_bytes()).decode('ascii')

def build() -> Path:
    content = TEMPLATE.read_text(encoding='utf-8')
    for key, path in IMAGES.items():
        if not path.is_file():
            raise FileNotFoundError(f'Missing screenshot: {path}')
        ext = path.suffix.lower()
        if ext not in ('.png', '.jpg', '.jpeg'):
            raise ValueError(f'Unsupported image type: {path}')
        mime = 'image/png' if ext == '.png' else 'image/jpeg'
        token = '{{' + key + '_BASE64}}'
        content = content.replace('data:image/png;base64,' + token,
                                  'data:' + mime + ';base64,' + image_to_base64(path))
    for key, url in URLS.items():
        content = content.replace('{{' + key + '}}', html.escape(url, quote=True))
    unresolved = re.findall(r'\{\{[^{}]+\}\}', content)
    if unresolved:
        raise ValueError(f'Unresolved placeholders: {unresolved}')
    OUTPUT.write_text(content, encoding='utf-8')
    return OUTPUT

if __name__ == '__main__':
    print('Generated:', build())
