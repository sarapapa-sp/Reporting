# Global Markets Trend Analysis

Install: `pip install -r requirements.txt`

Run dashboard: `TREND_ROOT=/path/to/data streamlit run Trend_dashboard.py`

Run without dashboard: `python run_trend.py --root /path/to/data --version Daily --cob-date 2026-11-04`

Source: `/root/YYYY/Flat_Conso_Reports_Mon.xlsx`; columns: `cob_date`, `version`, `report_name`, `indicator`, `daily`, `bus_count`. Values in kEUR, displayed/exported in mEUR.

Tabs: Heatmap, Line Graphs, Save File, Threshold Analysis. Report and indicator filters plus previous COB count and COB date are in one row. Plotly date labels are not rotated. Excel Heatmap Data headings are rotated 90 degrees.

Previous-month COB comparison uses the **original center-alignment mapping**: when current month has more business days, the central previous-month COB repeats; when previous month has more, central prior-month COBs are skipped. It uses Monday-Friday excluding EXCEPTION_COBS. Add actual bank holidays to EXCEPTION_COBS before production use. The `bus_count` in the workbook is used for the source-day field; calendar mapping should be checked against the bank's official COB calendar.

Historical reference excludes the selected COB; minimum reference observations are 5, 60, 100, 7, 10 and 20 for short, long, broad, month, quarter and full year. Backward loading crosses year boundaries. Missing historical COBs are not fabricated.

The Trend Excel sheet includes previous-month comparison columns; it does not include MTD or YTD. The Heatmap Data sheet contains mEUR daily P&L with Excel conditional formatting.
