"""Global Markets | Trend Analysis — Streamlit dashboard."""
import os
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from Publication_Trendv2 import ReportTrendAnalyzer, PERIODS
from Heatmap_Trend import generate_heatmap, generate_line_graph, history_to_pivot
from export_utils import make_excel

st.set_page_config(page_title='Global Markets | Trend Analysis', layout='wide')
st.title('Global Markets | Trend Analysis')
root=st.sidebar.text_input('Workbook root folder',os.getenv('TREND_ROOT','./data'))
@st.cache_data(ttl=300)
def latest(folder):return ReportTrendAnalyzer(folder).get_latest_cob_by_version()
@st.cache_data(ttl=300,show_spinner='Loading daily P&L...')
def load(folder,cob,comparison,months,period):
    a=ReportTrendAnalyzer(folder)
    try:return a.run_trend_analysis(cob,comparison,months,period)
    finally:a.close_logging()
try:
    recent=latest(root).get('daily')
    if not recent:st.warning('No Daily COB found. Check workbook root.');st.stop()
    a,b,c,d=st.columns([3,3,1.4,1.8])
    with d:cob=st.date_input('COB Date (as-of)',value=pd.Timestamp(recent).date())
    with c:n_cobs=st.number_input('Previous COBs',min_value=1,max_value=250,value=10)
    result=load(root,str(cob),max(5,int(n_cobs)),3,'n_business_days')
    pivot=history_to_pivot(result['history'],cob)
    with a:reports=st.multiselect('Reports',sorted(pivot['report_name'].unique()),default=sorted(pivot['report_name'].unique()))
    available=sorted(pivot[pivot['report_name'].isin(reports)]['indicator'].unique())
    with b:indicators=st.multiselect('Indicators',available,default=available)
    selected=pivot[pivot['report_name'].isin(reports)&pivot['indicator'].isin(indicators)]
    if selected.empty:st.info('Select at least one report and indicator.');st.stop()
    st.caption(f'Latest Daily COB: {recent} | P&L values: mEUR')
    heat,line,save,threshold=st.tabs(['Heatmap','Line Graphs','Save File','Threshold Analysis'])
    with heat:
        st.plotly_chart(generate_heatmap(selected,'All Reports',int(n_cobs),'Global Markets | P&L Heatmap'),use_container_width=True)
    with line:
        st.plotly_chart(generate_line_graph(selected,'All Reports',indicators,int(n_cobs)),use_container_width=True)
    with save:
        st.subheader('Save Trend Analysis')
        with st.form('export'):
            e1,e2,e3,e4=st.columns(4)
            with e1:export_cob=st.date_input('Export COB',cob)
            with e2:comparison=st.number_input('Comparison COBs',min_value=1,value=5)
            with e3:months=st.number_input('Months to load',min_value=1,value=3)
            with e4:period=st.selectbox('Trend period',['n_business_days','current_quarter','current_year','all'])
            submit=st.form_submit_button('Prepare Excel')
        if submit:
            export_result=load(root,str(export_cob),int(comparison),int(months),period)
            st.session_state['export_bytes']=make_excel(export_result)
            st.session_state['export_date']=str(export_cob)
        if st.session_state.get('export_bytes'):
            st.download_button('Download Excel (mEUR)',st.session_state['export_bytes'],
                file_name=f"publication_trend_{st.session_state['export_date']}.xlsx",
                mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        st.caption('Trend sheet includes previous-month comparison. Heatmap Data sheet has 90° date headers. No MTD/YTD.')
    with threshold:
        st.subheader('Daily P&L Threshold Analysis')
        t1,t2,t3=st.columns(3)
        with t1:report=st.selectbox('Report',sorted(selected['report_name'].unique()))
        with t2:indicator=st.selectbox('Indicator',sorted(selected[selected['report_name']==report]['indicator'].unique()))
        with t3:occurrence=st.selectbox('Window',PERIODS)
        matches=result['trend'].query('report_name == @report and indicator == @indicator')
        if matches.empty:st.info('No trend result for selected report and indicator.')
        else:
            r=matches.iloc[0]
            if r[f'{occurrence}_status']!='ok':st.info('Insufficient historical observations.')
            else:
                hist=result['history'];hist=hist[(hist['report_name']==report)&(hist['indicator']==indicator)]
                win=ReportTrendAnalyzer(root)._window(hist,pd.Timestamp(cob),occurrence)
                fig=go.Figure(go.Histogram(x=win['daily']/1000,name='Historical P&L'))
                mean=float(r[f'{occurrence}_avg'])/1000;std=float(r[f'{occurrence}_std'])/1000
                for value,label,color in [(mean,'Mean','#2563eb'),(mean-2*std,'Lower threshold','#dc2626'),
                                          (mean+2*std,'Upper threshold','#dc2626'),(float(r['daily'])/1000,'Current COB','#16a34a')]:
                    fig.add_vline(x=value,line_dash='dash',line_color=color,annotation_text=label)
                fig.update_layout(template='plotly_white',xaxis_title='Daily P&L (mEUR)',yaxis_title='Observations')
                st.plotly_chart(fig,use_container_width=True)
                st.caption(f"Reference: {r[f'{occurrence}_start']} to {r[f'{occurrence}_end']} (current COB excluded)")
except Exception as exc:
    st.error(f'Unable to load dashboard: {exc}')
