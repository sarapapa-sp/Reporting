from io import BytesIO
import pandas as pd

MONETARY_COLUMNS={'daily','previous_month_daily','previous_month_change'}
MONETARY_SUFFIXES=('_avg','_std','_min','_max','_slope','_change')

def convert_to_meur(frame):
    out=frame.copy()
    for col in out.columns:
        if (col in MONETARY_COLUMNS or col.endswith(MONETARY_SUFFIXES)) and pd.api.types.is_numeric_dtype(out[col]):
            out[col]=out[col]/1000.0
    return out

def make_excel(result):
    output=BytesIO()
    with pd.ExcelWriter(output,engine='openpyxl') as writer:
        for key,sheet in [('trend','Trend'),('comparison','Previous Month Comparison')]:
            df=convert_to_meur(result[key]).drop(columns=['mtd','ytd'],errors='ignore')
            df.to_excel(writer,index=False,sheet_name=sheet)
            ws=writer.sheets[sheet];ws.freeze_panes='D2';ws.auto_filter.ref=ws.dimensions
            for column in ws.columns:
                ws.column_dimensions[column[0].column_letter].width=25 if column[0].value in ('report_name','indicator') else 19
    return output.getvalue()
