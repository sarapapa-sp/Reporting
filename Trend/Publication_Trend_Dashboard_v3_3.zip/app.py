"""Original heatmap-first dashboard, enhanced with line graph, trend and export."""
import os
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from Publication_Trendv2 import ReportTrendAnalyzer, PERIODS
from Heatmap_Trend import generate_heatmap, generate_line_graph, history_to_pivot
from export_utils import convert_to_meur,make_excel
st.set_page_config(page_title='Global Markets P&L Trends',layout='wide')
st.title('Global Markets P&L Trend Dashboard')
root=st.sidebar.text_input('Workbook root folder',os.getenv('TREND_ROOT','./data'))
@st.cache_data(ttl=300,show_spinner=False)
def recent(folder):return ReportTrendAnalyzer(folder).get_latest_cob_by_version()
@st.cache_data(ttl=300,show_spinner='Loading daily P&L trends...')
def load(folder,cob,comparison,months,period):
    return ReportTrendAnalyzer(folder).run_trend_analysis(cob,comparison,months,period)
try:
    latest=recent(root).get('daily')
    if latest is None:st.warning('No Daily COB available in the configured workbook folder.');st.stop()
    cob=st.date_input('Selected COB',pd.Timestamp(latest).date())
    st.caption(f'Latest available Daily COB: {latest} | Display values: mEUR')
    data=load(root,str(cob),5,3,'n_business_days')
    pivot=history_to_pivot(data['history'],cob)
    reports=['All Reports']+sorted(pivot['report_name'].astype(str).unique().tolist())
    a,b=st.columns(2)
    with a:report=st.selectbox('Report',reports)
    with b:n_cobs=st.number_input('Previous N COBs',min_value=1,max_value=max(1,len(pivot.columns)-2),value=min(5,len(pivot.columns)-2))
    st.subheader('Daily P&L Heatmap')
    st.plotly_chart(generate_heatmap(pivot,report,int(n_cobs),'Daily P&L Heatmap (mEUR)'),use_container_width=True)
    st.subheader('Daily P&L Line Graph')
    filtered=pivot if report=='All Reports' else pivot[pivot['report_name']==report]
    indicators=sorted(filtered['indicator'].astype(str).unique().tolist())
    chosen=st.multiselect('Indicators',indicators,default=indicators[:min(8,len(indicators))])
    if chosen:st.plotly_chart(generate_line_graph(pivot,report,chosen,int(n_cobs)),use_container_width=True)
    st.subheader('Previous-month COB comparison')
    st.dataframe(convert_to_meur(data['comparison']),use_container_width=True,hide_index=True)
    st.subheader('Statistical trend parameters')
    st.dataframe(convert_to_meur(data['trend']),use_container_width=True,hide_index=True)
    with st.expander('P&L distribution and Z-score thresholds'):
        trend=data['trend'];report_d=st.selectbox('Distribution report',sorted(trend['report_name'].unique()))
        indicators_d=sorted(trend.loc[trend['report_name']==report_d,'indicator'].unique())
        indicator_d=st.selectbox('Distribution indicator',indicators_d)
        period_d=st.selectbox('Occurrence',PERIODS)
        row=trend[(trend['report_name']==report_d)&(trend['indicator']==indicator_d)].iloc[0]
        if row[f'{period_d}_status']!='ok':st.info('Insufficient observations for this period.')
        else:
            subset=data['history'];subset=subset[(subset['report_name']==report_d)&(subset['indicator']==indicator_d)]
            win=ReportTrendAnalyzer(root)._window(subset,pd.Timestamp(cob),period_d)
            fig=go.Figure(go.Histogram(x=win['daily']/1000,name='Historical daily P&L'))
            mu=row[f'{period_d}_avg']/1000;std=row[f'{period_d}_std']/1000
            for x,label,color in [(mu,'Mean','#3b82f6'),(mu-2*std,'Lower Z=-2','#ef4444'),(mu+2*std,'Upper Z=+2','#ef4444'),(row['daily']/1000,'Current COB','#10b981')]:
                fig.add_vline(x=x,line_dash='dash',line_color=color,annotation_text=label)
            fig.update_layout(template='plotly_white',xaxis_title='Daily P&L (mEUR)')
            st.plotly_chart(fig,use_container_width=True)
    st.subheader('Save file')
    with st.form('export'):
        export_cob=st.date_input('Export COB date',cob,key='export_cob')
        comparison=st.number_input('Comparison COBs',min_value=1,value=5)
        months=st.number_input('Months to load',min_value=1,value=3)
        period=st.selectbox('Trend period',['n_business_days','current_quarter','current_year','all'])
        submitted=st.form_submit_button('Prepare Excel file')
    if submitted:
        result=load(root,str(export_cob),int(comparison),int(months),period)
        st.download_button('Download Excel (mEUR)',make_excel(result),file_name=f'publication_trend_{export_cob}.xlsx',
            mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
except Exception as exc:
    st.error(str(exc))
