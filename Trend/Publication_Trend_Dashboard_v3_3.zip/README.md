# Publication Trend Dashboard v3

## Install and run
`pip install -r requirements.txt`
`TREND_ROOT=/path/to/monthly/workbooks streamlit run app.py`

Input files: `<root>/<year>/Report_data_<Mon>.xlsx` with `cob_date, version, report_name, indicator, daily` columns (optional additional columns). Input P&L is kEUR; dashboard and Excel output are mEUR.

Default dashboard COB is the latest **Daily** COB discovered across all year/month workbooks. Historical reference excludes selected COB. Minimum reference observations: 5, 60, 100, 7, 10, 20 for short, long, broad, month, quarter, full year. The 100-COB window is distinct from full-year analysis. Distribution is per report/indicator.

## Notes
- This is a standalone implementation based on the publicly accessible analyzer interface, **not a byte-for-byte patch of all previous dashboard scripts**.
- `run_trend_analysis()` returns a dict with `trend` and `history`. Existing downstream consumers requiring other dict keys must be adapted.
- Data continuity and calendar holiday policies should be aligned with the production calendar before deployment.
- Historical workbook loading now walks backward across calendar years until every selected-COB report/indicator has 100 prior COB observations, or the earliest available workbook year is exhausted. If history is insufficient, the period shows `insufficient_data`. Missing months are logged.
- `get_latest_cob_by_version()` scans workbooks; Streamlit caches results for five minutes.
- Percentage change uses absolute first historical observation as denominator.
- Excel export deliberately excludes MTD/YTD.

## Previous-month comparison (restored)
The input workbook must include `bus_day`. The last `--comparison-cob` available current-month COB dates (default 5) are matched to the same `bus_day` in the previous calendar month. When a current business-day count exceeds the last available prior-month business-day count, the last prior-month COB is reused; consequently multiple current COBs can share one previous-month COB. Missing matches remain blank, not fabricated. Results are returned in `run_trend_analysis(...)["comparison"]` and exported as a second Excel sheet. This implementation is a reconstruction; confirm special-case rules against your original production script.

## Standalone command-line runner
`python run_trend.py --root /path/to/data --cob-date 2027-01-05 --version Daily --comparison-cob 5 --months-to-load 3 --trend-period n_business_days --output result.xlsx`
Omit `--cob-date` to automatically use the latest COB for the requested version. The output includes Trend and Previous Month Comparison sheets, with monetary values converted from kEUR to mEUR. Logging continues in the root's `logs` directory.

## v3.3 corrections (2026-11-11)
- Restores heatmap-first dashboard based on GitHub `Heatmap_Trend.py` design, with multi-step red/green heatmap, rotated COB labels, Plotly-colored line graph, and separate Excel export controls.
- Uses `Flat_Conso_Reports_<Mon>.xlsx` in `<root>/<year>/` and `bus_count` rather than `bus_day`.
- Adds `Heatmap_Trend.py` utilities and keeps standalone `run_trend.py`.
- Previous-month comparison now uses proportional `ceil(current_bus_count * previous_month_total / current_month_total)` rather than capping the same day. **Important**: the current-month total is inferred from the maximum `bus_count` available in the workbook; if the workbook contains only month-to-date rows, the full-month business-day total is unknown and this mapping is provisional. Provide a complete month business calendar or a month-total lookup for accurate comparisons before month end.
- Calculations remain in kEUR internally, dashboard/Excel monetary values are in mEUR.
- Original GitHub heatmap code was inspected in the browser; this is a compatible reconstruction, not an exact source-code copy. Validate with production files.
