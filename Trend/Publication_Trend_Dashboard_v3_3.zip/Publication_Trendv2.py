"""Daily report/indicator trend analysis. Input: root/YYYY/Flat_Conso_Reports_Mon.xlsx."""
from __future__ import annotations
from pathlib import Path
import logging
import numpy as np
import pandas as pd

PERIODS = ("short","long","broad","month","quarter","fullyear")
MINIMUM = {"short":5,"long":60,"broad":100,"month":7,"quarter":10,"fullyear":20}
REQUIRED = ("cob_date","version","report_name","indicator","daily")
MONETARY_SUFFIXES = ("_avg","_std","_min","_max","_slope","_change")
class ReportTrendAnalyzer:
    EXCEPTION_COBS = frozenset({"2026-01-01"})
    def __init__(self,root_folder,version="Daily",short_window=5,long_window=60,
                 broad_window=100,anomaly_z_threshold=2.0,log_folder=None,as_of_date=None):
        self.root_folder=Path(root_folder)
        self.version=version
        self.windows={"short":short_window,"long":long_window,"broad":broad_window}
        if not (2 <= short_window <= long_window <= broad_window):
            raise ValueError("Invalid window sizes")
        self.anomaly_z_threshold=float(anomaly_z_threshold)
        self.log_folder=Path(log_folder) if log_folder else self.root_folder/"logs"
        self.logger=logging.getLogger(f"trend.{id(self)}")
        self.logger.setLevel(logging.INFO); self.logger.propagate=False
        self.log_path=None
        if as_of_date is not None: self.setup_logging(as_of_date)
    def setup_logging(self,cob_date):
        from datetime import datetime
        self.close_logging()
        self.log_folder.mkdir(parents=True,exist_ok=True)
        self.log_path=self.log_folder/f"log_trend_{pd.Timestamp(cob_date):%Y%m%d}_{datetime.now():%Y%m%d_%H%M%S_%f}.log"
        handler=logging.FileHandler(self.log_path,encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(message)s"))
        self.logger.addHandler(handler)
        return self.log_path
    def close_logging(self):
        for h in list(self.logger.handlers):
            h.flush();h.close();self.logger.removeHandler(h)
    def _log(self,cob):
        if self.log_path is None:self.setup_logging(cob)
    def generate_filename(self,cob_date):
        return f"Flat_Conso_Reports_{pd.Timestamp(cob_date):%b}.xlsx"
    def generate_file_path(self,cob_date):
        d=pd.Timestamp(cob_date);return self.root_folder/str(d.year)/self.generate_filename(d)
    def file_exists(self,cob_date):
        return self.generate_file_path(cob_date).is_file()
    def get_latest_cob_by_version(self):
        """Read each available monthly workbook and find max COB per version."""
        result={"daily":None,"flash":None,"final":None}
        for path in sorted(self.root_folder.glob("*/Flat_Conso_Reports_*.xlsx")):
            try:
                df=pd.read_excel(path,usecols=lambda c:str(c).strip().lower() in ("cob_date","version"))
                df.columns=df.columns.str.strip().str.lower()
                if not {"cob_date","version"}.issubset(df):continue
                df["cob_date"]=pd.to_datetime(df["cob_date"],errors="coerce")
                for key,group in df.groupby(df["version"].astype(str).str.strip().str.lower()):
                    if key in result and group["cob_date"].notna().any():
                        value=group["cob_date"].max().normalize()
                        if result[key] is None or value>pd.Timestamp(result[key]):
                            result[key]=value.strftime("%Y-%m-%d")
            except Exception as exc:
                self.logger.warning("Unable to inspect workbook %s: %s",path.name,exc)
        return result
    def required_months_to_load(self,as_of_date,trend_period="n_business_days",months_to_load=3):
        asof=pd.Timestamp(as_of_date)
        if trend_period in ("current_year","all","fullyear"):
            return max(months_to_load,asof.month)
        if trend_period in ("current_quarter","quarter"):
            return max(months_to_load,(asof.month-1)%3+1)
        return months_to_load
    def get_history_paths(self,as_of_date,months_to_load=3):
        period=pd.Timestamp(as_of_date).to_period("M")
        return [self.generate_file_path((period-i).start_time) for i in range(months_to_load-1,-1,-1)]
    def load_daily_data(self,as_of_date,months_to_load=3):
        """Load backwards across years until each current report/indicator has broad history.

        Also covers the selected calendar year for full-year statistics. A missing
        historical workbook is logged; unavailable observations are never invented.
        """
        asof=pd.Timestamp(as_of_date).normalize();self._log(asof)
        current_path=self.generate_file_path(asof)
        if not current_path.is_file():
            raise FileNotFoundError(f"Missing selected-COB workbook: {current_path.name}")
        period=asof.to_period("M")
        available=sorted((p for p in self.root_folder.glob("*/Flat_Conso_Reports_*.xlsx") if p.is_file()))
        earliest_year=min((int(p.parent.name) for p in available if p.parent.name.isdigit()),default=asof.year)
        earliest=pd.Period(f"{earliest_year}-01",freq="M")
        # Ensure full-year coverage, even if 100 observations are found earlier.
        min_months=max(int(months_to_load),asof.month)
        frames=[];loaded=[];current_keys=None
        required=self.windows["broad"]
        month_index=0
        while period>=earliest:
            path=self.generate_file_path(period.start_time)
            loaded.append(path.name)
            if not path.is_file():
                self.logger.warning("Missing workbook: %s",path.name)
            else:
                df=pd.read_excel(path)
                df.columns=df.columns.astype(str).str.strip().str.lower()
                missing=set(REQUIRED)-set(df.columns)
                if missing:raise ValueError(f"{path.name}: missing {sorted(missing)}")
                df=df[df["version"].astype(str).str.strip().str.casefold()==self.version.casefold()].copy()
                df["cob_date"]=pd.to_datetime(df["cob_date"],errors="coerce").dt.normalize()
                df["daily"]=pd.to_numeric(df["daily"],errors="coerce")
                df=df[df["cob_date"]<=asof]
                if df[list(REQUIRED)].isna().any().any():raise ValueError(f"Invalid rows in {path.name}")
                dates=sorted(df["cob_date"].dt.strftime("%Y-%m-%d").unique().tolist())
                self.logger.info("Workbook=%s | COBs=%s",path.name,dates)
                frames.append(df)
                if period==asof.to_period("M"):
                    current_keys=set(map(tuple,df.loc[df["cob_date"]==asof,["report_name","indicator"]].to_numpy()))
            month_index+=1
            if month_index>=min_months and current_keys and frames:
                accumulated=pd.concat(frames,ignore_index=True)
                historical=accumulated[accumulated["cob_date"]<asof]
                counts=historical.groupby(["report_name","indicator"])["cob_date"].nunique()
                if all(counts.get(key,0)>=required for key in current_keys):break
            period-=1
        self.logger.info("Requested workbooks=%s",loaded)
        if not frames:raise ValueError("No history found")
        data=pd.concat(frames,ignore_index=True)
        if data.duplicated(["cob_date","report_name","indicator"]).any():
            raise ValueError("Duplicate COB/report/indicator records")
        if current_keys:
            hist=data[data["cob_date"]<asof].groupby(["report_name","indicator"])["cob_date"].nunique()
            lacking={str(k):int(hist.get(k,0)) for k in current_keys if hist.get(k,0)<required}
            if lacking:self.logger.warning("Broad history below %s COBs: %s",required,lacking)
        return data.sort_values(["report_name","indicator","cob_date"]).reset_index(drop=True)
    def _window(self,history,asof,occurrence):
        if occurrence not in PERIODS:raise ValueError(f"occurrence must be one of {PERIODS}")
        ref=history[history["cob_date"]<asof].sort_values("cob_date")
        if occurrence in self.windows:return ref.tail(self.windows[occurrence])
        start=(asof.to_period({"month":"M","quarter":"Q","fullyear":"Y"}[occurrence]).start_time)
        return ref[ref["cob_date"]>=start]
    def _stats(self,window,current,period):
        vals=window["daily"].to_numpy(dtype=float)
        count=len(vals); min_obs=self.windows.get(period,MINIMUM[period])
        out={f"{period}_start":window["cob_date"].min().strftime("%Y-%m-%d") if count else None,
             f"{period}_end":window["cob_date"].max().strftime("%Y-%m-%d") if count else None,
             f"{period}_observations":count,
             f"{period}_status":"ok" if count>=min_obs else "insufficient_data"}
        trend=("avg","std","zscore","anomaly","direction")
        assoc=("min","max","change","change_pct","slope")
        for key in trend+assoc:out[f"{period}_{key}"]=None
        if count<min_obs:return out
        avg=float(np.mean(vals));std=float(np.std(vals,ddof=1))
        slope=float(np.polyfit(np.arange(count),vals,1)[0])
        z=(float(current)-avg)/std if std>0 else (0.0 if current==avg else None)
        out.update({f"{period}_avg":avg,f"{period}_std":std,f"{period}_zscore":z,
                    f"{period}_anomaly":(abs(z)>=self.anomaly_z_threshold if z is not None else current!=avg),
                    f"{period}_direction":"Rising" if slope>1e-10 else "Falling" if slope< -1e-10 else "Flat",
                    f"{period}_min":float(vals.min()),f"{period}_max":float(vals.max()),
                    f"{period}_change":float(vals[-1]-vals[0]),
                    f"{period}_change_pct":float(100*(vals[-1]-vals[0])/abs(vals[0])) if vals[0] else None,
                    f"{period}_slope":slope})
        return out
    def calculate_trend_parameters(self,daily_data,as_of_date):
        asof=pd.Timestamp(as_of_date).normalize();self._log(asof)
        data=daily_data.copy();data["cob_date"]=pd.to_datetime(data["cob_date"]).dt.normalize()
        data=data[data["cob_date"]<=asof]
        rows=[]
        for (report,indicator),grp in data.groupby(["report_name","indicator"],sort=True):
            current=grp[grp["cob_date"]==asof]
            if current.empty:continue
            value=float(current.iloc[-1]["daily"])
            row={"cob_date":asof.strftime("%Y-%m-%d"),"report_name":report,"indicator":indicator,
                 "daily":value,"version":self.version}
            for period in PERIODS:
                window=self._window(grp,asof,period)
                row.update(self._stats(window,value,period))
                self.logger.info("Report=%s | indicator=%s | period=%s | COBs=%s",
                                 report,indicator,period,window["cob_date"].dt.strftime("%Y-%m-%d").tolist())
            row["computed_cols"]=", ".join(p for p in PERIODS if row[p+"_status"]=="ok")
            rows.append(row)
        if not rows:raise ValueError(f"No selected COB rows for {asof.date()}")
        trendcols=[f"{p}_{k}" for p in PERIODS for k in ("avg","std","zscore","anomaly","direction")]
        assoccols=[f"{p}_{k}" for p in PERIODS for k in ("min","max","change","change_pct","slope")]
        meta=["daily","version","computed_cols"]+[f"{p}_{k}" for p in PERIODS for k in ("start","end","observations","status")]
        return pd.DataFrame(rows)[["cob_date","report_name","indicator"]+trendcols+assoccols+meta]
    def generate_trend_parameters(self,as_of_date,months_to_load=3):
        return self.calculate_trend_parameters(self.load_daily_data(as_of_date,months_to_load),as_of_date)
    def get_previous_month_comparison(self, history, cob_date, comparison_cob=5):
        """Match last N current-month COBs to prior-month bus_count, capped at prior month's last bus_count.

        Multiple current COBs may map to the same previous-month COB when the prior
        month is shorter. Comparisons are per report/indicator and version.
        """
        asof=pd.Timestamp(cob_date).normalize()
        if int(comparison_cob)<1:raise ValueError("comparison_cob must be >= 1")
        data=history.copy()
        if "bus_count" not in data.columns:
            raise ValueError("Previous-month comparison requires 'bus_count' in monthly workbooks")
        data["bus_count"]=pd.to_numeric(data["bus_count"],errors="coerce")
        if data["bus_count"].isna().any():raise ValueError("Invalid bus_count values")
        this_month=asof.to_period("M")
        prev_month=this_month-1
        current=data[(data["cob_date"].dt.to_period("M")==this_month)&(data["cob_date"]<=asof)]
        dates=sorted(current["cob_date"].unique(),reverse=True)[:int(comparison_cob)]
        current=current[current["cob_date"].isin(dates)].copy()
        previous=data[data["cob_date"].dt.to_period("M")==prev_month].copy()
        if previous.empty:
            self.logger.warning("No previous-month COBs for %s",prev_month)
            current["previous_month_cob"]=pd.NaT
            current["previous_month_daily"]=float("nan")
        else:
            # Proportional business-day alignment across different month lengths.
            # Count business days from the full month calendar, not just the current COB slice.
            import math
            prev_days=previous[["bus_count","cob_date"]].drop_duplicates()
            current_total=int(data.loc[data["cob_date"].dt.to_period("M")==this_month,"bus_count"].max())
            previous_total=int(prev_days["bus_count"].max())
            if current_total<1 or previous_total<1:
                raise ValueError("Invalid month business-day totals")
            current["matched_bus_count"]=current["bus_count"].map(
                lambda day: min(previous_total,max(1,math.ceil(int(day)*previous_total/current_total))))
            self.logger.info("Business-day mapping current month total=%s | prior month total=%s | mapping=%s",
                             current_total,previous_total,
                             list(zip(current["bus_count"].tolist(),current["matched_bus_count"].tolist())))
            previous=previous.rename(columns={"cob_date":"previous_month_cob","daily":"previous_month_daily"})
            previous=previous.sort_values("previous_month_cob").drop_duplicates(
                ["report_name","indicator","bus_count"],keep="last")
            current=current.merge(previous[["report_name","indicator","bus_count","previous_month_cob","previous_month_daily"]],
                left_on=["report_name","indicator","matched_bus_count"],
                right_on=["report_name","indicator","bus_count"],how="left",suffixes=("","_prior"))
        current["previous_month_change"]=current["daily"]-current["previous_month_daily"]
        denominator=current["previous_month_daily"].abs().replace(0,float("nan"))
        current["previous_month_change_pct"]=100*current["previous_month_change"]/denominator
        columns=["cob_date","report_name","indicator","bus_count","daily","previous_month_cob",
                 "previous_month_daily","previous_month_change","previous_month_change_pct"]
        result=current[columns].sort_values(["cob_date","report_name","indicator"],ascending=[False,True,True])
        self.logger.info("Previous-month comparisons: current COBs=%s | previous COBs=%s",
                         sorted(result["cob_date"].dt.strftime("%Y-%m-%d").unique().tolist()),
                         sorted(result["previous_month_cob"].dropna().dt.strftime("%Y-%m-%d").unique().tolist()))
        return result.reset_index(drop=True)
    def run_trend_analysis(self,cob_date,comparison_cob=5,months_to_load=3,trend_period="n_business_days"):
        history=self.load_daily_data(cob_date,months_to_load)
        trend=self.calculate_trend_parameters(history,cob_date)
        comparison=self.get_previous_month_comparison(history,cob_date,comparison_cob)
        return {"trend":trend,"history":history,"comparison":comparison}
    def get_daily_pnl_distribution(self,cob_date,occurrence,report_name,indicator,months_to_load=12):
        asof=pd.Timestamp(cob_date).normalize()
        history=self.load_daily_data(asof,months_to_load)
        group=history[(history["report_name"]==report_name)&(history["indicator"]==indicator)]
        current=group[group["cob_date"]==asof]
        if current.empty:raise ValueError("No selected COB for report and indicator")
        window=self._window(group,asof,occurrence)
        stats=self._stats(window,float(current.iloc[-1]["daily"]),occurrence)
        avg=stats[f"{occurrence}_avg"];std=stats[f"{occurrence}_std"]
        threshold=self.anomaly_z_threshold
        return {"cob_date":asof.strftime("%Y-%m-%d"),"report_name":report_name,"indicator":indicator,
                "occurrence":occurrence,"current_daily":float(current.iloc[-1]["daily"]),
                "mean":avg,"std":std,"zscore":stats[f"{occurrence}_zscore"],
                "zscore_threshold":threshold,
                "lower_endpoint":avg-threshold*std if avg is not None else None,
                "upper_endpoint":avg+threshold*std if avg is not None else None,
                "historical_values":window["daily"].tolist(),"status":stats[f"{occurrence}_status"],
                "period_start":stats[f"{occurrence}_start"],"period_end":stats[f"{occurrence}_end"]}
    def get_previous_daily_pnl(self,as_of_date,n,months_to_load=3,history=None):
        data=history if history is not None else self.load_daily_data(as_of_date,months_to_load)
        data=data[data["cob_date"]<=pd.Timestamp(as_of_date)]
        dates=sorted(data["cob_date"].unique(),reverse=True)[:n]
        selected=data[data["cob_date"].isin(dates)].copy()
        selected["cob_date"]=selected["cob_date"].dt.strftime("%Y-%m-%d")
        cols=[pd.Timestamp(d).strftime("%Y-%m-%d") for d in dates]
        return selected.pivot(index=["report_name","indicator"],columns="cob_date",values="daily").reindex(columns=cols).reset_index()
    def parameters_for_llm(self,as_of_date,months_to_load=3):
        import json
        return json.loads(self.generate_trend_parameters(as_of_date,months_to_load).to_json(orient="records"))
