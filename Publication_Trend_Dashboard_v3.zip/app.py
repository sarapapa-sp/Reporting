import os
from io import BytesIO
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from Publication_Trendv2 import ReportTrendAnalyzer, PERIODS

st.set_page_config(page_title="Publication Trends",layout="wide")
st.title("Publication P&L Trend Dashboard")
root=st.sidebar.text_input("Workbook root folder",os.getenv("TREND_ROOT","./data"))
analyzer=ReportTrendAnalyzer(root)
@st.cache_data(ttl=300,show_spinner=False)
def latest_dates(folder):
    return ReportTrendAnalyzer(folder).get_latest_cob_by_version()
try:
    versions=latest_dates(root)
    latest=versions.get("daily")
    if latest is None:
        st.warning("No Daily COB found. Check the workbook root folder.")
        st.stop()
    st.caption(f"Latest available Daily COB: {latest}")
    cob=st.date_input("COB date",value=pd.Timestamp(latest).date())
    comparison=st.number_input("Comparison COBs",min_value=1,value=5)
    months=st.number_input("Months to load (minimum automatically expanded)",min_value=1,value=3)
    trend_period=st.selectbox("Trend period",["n_business_days","current_quarter","current_year","all"])
    @st.cache_data(ttl=300,show_spinner="Calculating trends...")
    def compute(folder,date,months,comparison,trend_period):
        a=ReportTrendAnalyzer(folder,version="Daily")
        return a.run_trend_analysis(date,comparison,months,trend_period)
    data=compute(root,str(cob),months,comparison,trend_period)
    trend=data["trend"]
    monetary=lambda c: c=="daily" or c.endswith(("_avg","_std","_min","_max","_slope","_change"))
    def to_meur(df):
        out=df.copy()
        for c in out.columns:
            if monetary(c) and pd.api.types.is_numeric_dtype(out[c]):
                out[c]=out[c]/1000
        return out
    view=to_meur(trend)
    st.subheader("Trend analysis")
    st.caption("All monetary values in mEUR. Z-scores and percentages remain unscaled.")
    st.dataframe(view,use_container_width=True,hide_index=True)
    st.subheader("P&L distribution")
    reports=sorted(trend["report_name"].dropna().unique().tolist())
    report=st.selectbox("Report",reports)
    indicators=sorted(trend.loc[trend["report_name"]==report,"indicator"].dropna().unique().tolist())
    indicator=st.selectbox("Indicator",indicators)
    occurrence=st.selectbox("Occurrence",PERIODS)
    group=data["history"]
    group=group[(group["report_name"]==report)&(group["indicator"]==indicator)]
    a=ReportTrendAnalyzer(root)
    window=a._window(group,pd.Timestamp(cob),occurrence)
    selected=trend[(trend["report_name"]==report)&(trend["indicator"]==indicator)].iloc[0]
    mean=selected[f"{occurrence}_avg"];std=selected[f"{occurrence}_std"]
    if pd.isna(mean) or pd.isna(std):
        st.info(f"Insufficient observations for {occurrence}: {selected[f'{occurrence}_observations']}")
    else:
        fig=go.Figure()
        fig.add_trace(go.Histogram(x=window["daily"]/1000,name="Historical P&L",opacity=.75))
        for x,label,color in [(mean/1000,"Mean","#3b82f6"),
                              ((mean-2*std)/1000,"Lower Z threshold","#ef4444"),
                              ((mean+2*std)/1000,"Upper Z threshold","#ef4444"),
                              (selected["daily"]/1000,"Current COB","#10b981")]:
            fig.add_vline(x=x,line_dash="dash",line_color=color,annotation_text=label)
        fig.update_layout(xaxis_title="Daily P&L (mEUR)",yaxis_title="Observations",
                          template="plotly_white",bargap=.08)
        st.plotly_chart(fig,use_container_width=True)
        st.caption(f"Reference dates: {selected[f'{occurrence}_start']} to {selected[f'{occurrence}_end']} "
                   f"({selected[f'{occurrence}_observations']} observations; current COB excluded)")
    st.subheader("Save trend to Excel")
    if st.button("Prepare Excel export"):
        output=BytesIO()
        with pd.ExcelWriter(output,engine="openpyxl") as writer:
            view.to_excel(writer,index=False,sheet_name="Trend")
            ws=writer.sheets["Trend"]
            ws.freeze_panes="D2"
            ws.auto_filter.ref=ws.dimensions
            for col in ws.columns:
                name=col[0].value
                letter=col[0].column_letter
                ws.column_dimensions[letter].width=17 if name not in ("report_name","indicator") else 25
        st.download_button("Download Excel (mEUR)",output.getvalue(),
                           file_name=f"publication_trend_{cob}.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
except Exception as exc:
    st.error(str(exc))
    st.exception(exc)
