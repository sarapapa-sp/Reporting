"""Plotly charts and Excel export for pre-pivoted Global Markets P&L data.

Input DataFrame structure:
    report_name | indicator | 2026-11-04 | 2026-11-05 | ...

The chart methods return Plotly go.Figure objects (no Streamlit dependency).
The Excel export returns XLSX bytes, suitable for st.download_button.
Requires Python >= 3.10, pandas, numpy, plotly, openpyxl (for Excel only).
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date
from io import BytesIO

import numpy as np
import pandas as pd
import plotly.graph_objects as go


class GMTrendCharts:
    """Render and export trends from a pre-pivoted, COB-wide DataFrame."""

    REQUIRED_COLUMNS = ("report_name", "indicator")

    def __init__(self, df: pd.DataFrame):
        if not isinstance(df, pd.DataFrame) or df.empty:
            raise ValueError("A non-empty pandas DataFrame is required.")

        missing = set(self.REQUIRED_COLUMNS) - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {sorted(missing)}")

        self.df = df.copy()
        for col in self.REQUIRED_COLUMNS:
            if self.df[col].isna().any() or self.df[col].astype(str).str.strip().eq("").any():
                raise ValueError(f"Column '{col}' contains missing/blank values.")
            self.df[col] = self.df[col].astype(str).str.strip()

        if self.df.duplicated(list(self.REQUIRED_COLUMNS)).any():
            raise ValueError("Each (report_name, indicator) combination must be unique.")

        raw_date_columns = [col for col in df.columns if col not in self.REQUIRED_COLUMNS]
        if not raw_date_columns:
            raise ValueError("At least one COB-date column is required.")

        date_pairs = []
        for col in raw_date_columns:
            parsed = pd.to_datetime(str(col), errors="coerce")
            if pd.isna(parsed):
                raise ValueError(f"Invalid COB-date column: {col!r}")
            date_pairs.append((pd.Timestamp(parsed).date(), col))

        if len({d for d, _ in date_pairs}) != len(date_pairs):
            raise ValueError("More than one column refers to the same COB date.")

        date_pairs.sort(key=lambda item: item[0])
        self.date_columns = [col for _, col in date_pairs]  # ascending for line graphs
        self.date_labels = {col: d.strftime("%d %b %Y") for d, col in date_pairs}
        self.column_dates = {col: d for d, col in date_pairs}

        raw = self.df[self.date_columns]
        numeric = raw.apply(pd.to_numeric, errors="coerce")
        non_numeric = raw.notna() & numeric.isna()
        if non_numeric.any().any():
            raise ValueError("COB-date columns must contain numeric P&L values or NaN.")
        if np.isinf(numeric.to_numpy(dtype=float)).any():
            raise ValueError("Infinite P&L values are not supported.")
        if numeric.isna().all().all():
            raise ValueError("All COB P&L values are missing.")
        self.df[self.date_columns] = numeric

    @property
    def reports(self) -> list[str]:
        return sorted(self.df["report_name"].unique().tolist())

    @property
    def indicators(self) -> list[str]:
        return sorted(self.df["indicator"].unique().tolist())

    @staticmethod
    def _parse_end_cob(end_cob: date | str | pd.Timestamp | None) -> date | None:
        if end_cob is None:
            return None
        try:
            parsed = pd.to_datetime(end_cob, errors="raise")
            if pd.isna(parsed):
                raise ValueError
            return pd.Timestamp(parsed).date()
        except (ValueError, TypeError, OverflowError) as exc:
            raise ValueError(f"Invalid end_cob date: {end_cob!r}") from exc

    def _filter(self, reports=None, indicators=None, n_cobs=None, end_cob=None):
        """Return filtered rows and available COB columns, oldest to newest.

        end_cob is an inclusive as-of cutoff. If there is no data *on* the
        chosen date, the latest available COB before it is used.
        """
        data = self.df.copy()
        for column, selected in (("report_name", reports), ("indicator", indicators)):
            if selected is not None:
                if isinstance(selected, str):
                    values = [selected]
                elif isinstance(selected, Sequence):
                    values = list(selected)
                else:
                    raise ValueError(f"{column} filter must be a string or sequence of strings.")
                if not values:
                    raise ValueError(f"{column} filter cannot be empty.")
                data = data[data[column].isin(values)]

        if data.empty:
            raise ValueError("No rows match the selected reports/indicators.")

        if n_cobs is not None and (
            isinstance(n_cobs, bool) or not isinstance(n_cobs, int) or n_cobs < 1
        ):
            raise ValueError("n_cobs must be a positive integer or None.")

        cutoff = self._parse_end_cob(end_cob)
        dates = [
            col for col in self.date_columns
            if cutoff is None or self.column_dates[col] <= cutoff
        ]
        if not dates:
            raise ValueError("No COB dates in the DataFrame on or before the selected date.")
        if n_cobs is not None:
            dates = dates[-n_cobs:]
        if data[dates].isna().all().all():
            raise ValueError("No P&L values available for the selected rows and dates.")
        return data, dates

    def available_cobs(self, end_cob=None) -> list[date]:
        """All available source COB dates up to an optional inclusive cutoff."""
        cutoff = self._parse_end_cob(end_cob)
        return [
            self.column_dates[col] for col in self.date_columns
            if cutoff is None or self.column_dates[col] <= cutoff
        ]

    def create_heatmap(
        self,
        reports: str | Sequence[str] | None = None,
        indicators: str | Sequence[str] | None = None,
        n_cobs: int | None = None,
        title: str = "Global Markets | P&L Heatmap",
        end_cob: date | str | pd.Timestamp | None = None,
    ) -> go.Figure:
        """One report/indicator per row; latest COB shown on the left."""
        data, dates_ascending = self._filter(reports, indicators, n_cobs, end_cob)
        dates = list(reversed(dates_ascending))
        data = data.sort_values(["report_name", "indicator"])
        z = data[dates].to_numpy(dtype=float)
        max_abs = max(1.0, float(np.nanmax(np.abs(z))))
        row_labels = (
            data["report_name"].astype(str) + " | " + data["indicator"].astype(str)
        ).tolist()
        cell_text = [
            [f"{v:,.2f}" if np.isfinite(v) else "" for v in row]
            for row in z
        ]
        x_labels = [self.date_labels[c] for c in dates]
        fig = go.Figure(
            go.Heatmap(
                x=x_labels,
                y=row_labels,
                z=z,
                text=cell_text,
                texttemplate="%{text}",
                textfont=dict(size=11),
                colorscale=[
                    [0.0, "#C0392B"],
                    [0.5, "#F5F5F5"],
                    [1.0, "#27AE60"],
                ],
                zmin=-max_abs,
                zmax=max_abs,
                xgap=2,
                ygap=2,
                colorbar=dict(title="P&L"),
                hovertemplate=(
                    "<b>%{y}</b><br>COB: %{x}<br>"
                    "P&L: %{z:,.2f}<extra></extra>"
                ),
            )
        )
        fig.update_layout(
            title=title,
            xaxis=dict(title="COB Date", type="category", side="top"),
            yaxis=dict(title="Report | Indicator", type="category", autorange="reversed", automargin=True),
            height=max(380, min(1800, 130 + len(data) * 37)),
            margin=dict(l=30, r=30, t=85, b=35),
            template="plotly_white",
        )
        return fig

    def create_line_graph(
        self,
        indicators: str | Sequence[str] | None = None,
        reports: str | Sequence[str] | None = None,
        n_cobs: int | None = None,
        title: str = "Global Markets | P&L Trend by Report",
        end_cob: date | str | pd.Timestamp | None = None,
    ) -> go.Figure:
        """One line per report; selected indicators are summed within each report.

        Line charts retain chronological date order (oldest on left).
        Missing values stay missing if all selected indicators are missing.
        """
        data, dates = self._filter(reports, indicators, n_cobs, end_cob)
        totals = data.groupby("report_name", sort=True)[dates].sum(min_count=1)
        x_labels = [self.date_labels[c] for c in dates]
        fig = go.Figure()
        for report, row in totals.iterrows():
            fig.add_trace(
                go.Scatter(
                    x=x_labels,
                    y=row.to_numpy(dtype=float),
                    mode="lines+markers",
                    name=str(report),
                    line=dict(width=2.5),
                    marker=dict(size=6),
                    connectgaps=False,
                    hovertemplate=(
                        f"<b>{report}</b><br>"
                        "COB: %{x}<br>P&L: %{y:,.2f}<extra></extra>"
                    ),
                )
            )
        fig.update_layout(
            title=title,
            xaxis=dict(title="COB Date", type="category", tickangle=-35),
            yaxis=dict(title="P&L", zeroline=True, zerolinecolor="#888888"),
            hovermode="x unified",
            legend=dict(title="Report", orientation="h", y=-0.27),
            height=480,
            margin=dict(l=50, r=20, t=70, b=110),
            template="plotly_white",
        )
        return fig

    def export_trend_report_excel(
        self,
        reports: str | Sequence[str] | None = None,
        indicators: str | Sequence[str] | None = None,
        n_cobs: int | None = None,
        end_cob: date | str | pd.Timestamp | None = None,
        pnl_measure: str = "Daily",
    ) -> bytes:
        """Return a formatted three-sheet XLSX: heatmap, data, Excel-native trend chart."""
        from openpyxl import Workbook
        from openpyxl.chart import LineChart, Reference
        from openpyxl.formatting.rule import ColorScaleRule
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter

        data, dates_ascending = self._filter(reports, indicators, n_cobs, end_cob)
        data = data.sort_values(["report_name", "indicator"])
        dates_descending = list(reversed(dates_ascending))
        effective_cob = self.column_dates[dates_ascending[-1]]
        as_of = self._parse_end_cob(end_cob) or effective_cob
        totals = data.groupby("report_name", sort=True)[dates_ascending].sum(min_count=1)
        wb = Workbook()
        ws_heatmap = wb.active
        ws_heatmap.title = "P&L Heatmap"
        ws_raw = wb.create_sheet("Trend Data")
        ws_chart = wb.create_sheet("Trend Charts")
        navy = "17365D"
        light_blue = "EAF2F8"
        header_fill = PatternFill("solid", fgColor=navy)
        title_font = Font(size=15, bold=True, color=navy)
        number_fmt = '#,##0.00;[Red](#,##0.00);–'

        def add_sheet_header(ws, title: str) -> None:
            ws.sheet_view.showGridLines = False
            ws["A1"] = title
            ws["A1"].font = title_font
            ws["A2"] = "Selected COB"
            ws["B2"] = as_of
            ws["C2"] = "Latest available COB"
            ws["D2"] = effective_cob
            ws["E2"] = "P&L Measure"
            ws["F2"] = pnl_measure
            ws["A3"] = "Generated"
            ws["B3"] = pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S")
            ws["C3"] = "Reports"
            ws["D3"] = ", ".join(sorted(data["report_name"].unique()))
            ws["E3"] = "Indicators"
            ws["F3"] = ", ".join(sorted(data["indicator"].unique()))
            for col in ("B2", "D2"):
                ws[col].number_format = "dd mmm yyyy"
            for col in ("A2", "C2", "E2", "A3", "C3", "E3"):
                ws[col].font = Font(bold=True, color=navy)
            ws.row_dimensions[1].height = 26

        def format_header_row(ws, rownum: int, total_cols: int) -> None:
            for cells in ws.iter_rows(min_row=rownum, max_row=rownum,
                                      min_col=1, max_col=total_cols):
                for cell in cells:
                    cell.fill = header_fill
                    cell.font = Font(color="FFFFFF", bold=True)
                    cell.alignment = Alignment(horizontal="center")
            ws.row_dimensions[rownum].height = 23

        def write_data_row(ws, rownum: int, record, date_cols):
            ws.cell(rownum, 1, record["report_name"])
            ws.cell(rownum, 2, record["indicator"])
            for idx, col in enumerate(date_cols, start=3):
                val = record[col]
                cell = ws.cell(rownum, idx,
                               float(val) if pd.notna(val) else None)
                cell.number_format = number_fmt
                cell.alignment = Alignment(horizontal="right")
            if rownum % 2 == 0:
                for cell in ws[rownum]:
                    if cell.fill.patternType is None:
                        cell.fill = PatternFill("solid", fgColor="F5F8FB")

        for ws, title in (
            (ws_heatmap, "GLOBAL MARKETS | P&L HEATMAP"),
            (ws_raw, "GLOBAL MARKETS | TREND DATA"),
            (ws_chart, "GLOBAL MARKETS | TREND CHARTS"),
        ):
            add_sheet_header(ws, title)

        # Sheet 1: heatmap, newest COB first.
        heatmap_cols = [self.date_labels[c] for c in dates_descending]
        ws_heatmap.append([])  # row 4 populated explicitly below
        for idx, value in enumerate(["Report Name", "Indicator", *heatmap_cols], 1):
            ws_heatmap.cell(4, idx, value)
        format_header_row(ws_heatmap, 4, 2 + len(dates_descending))
        for rownum, (_, record) in enumerate(data.iterrows(), start=5):
            write_data_row(ws_heatmap, rownum, record, dates_descending)
        ws_heatmap.freeze_panes = "C5"
        ws_heatmap.auto_filter.ref = f"A4:{get_column_letter(2 + len(dates_descending))}{4 + len(data)}"
        values = data[dates_descending].to_numpy(dtype=float)
        finite = values[np.isfinite(values)]
        max_abs = max(1.0, float(np.max(np.abs(finite))))
        ws_heatmap.conditional_formatting.add(
            f"C5:{get_column_letter(2 + len(dates_descending))}{4 + len(data)}",
            ColorScaleRule(
                start_type="num", start_value=-max_abs, start_color="F8696B",
                mid_type="num", mid_value=0, mid_color="FFFFFF",
                end_type="num", end_value=max_abs, end_color="63BE7B",
            ),
        )

        # Sheet 2: underlying detail with dates ascending.
        for idx, value in enumerate(
            ["Report Name", "Indicator", *[self.date_labels[c] for c in dates_ascending]], 1
        ):
            ws_raw.cell(4, idx, value)
        format_header_row(ws_raw, 4, 2 + len(dates_ascending))
        for rownum, (_, record) in enumerate(data.iterrows(), start=5):
            write_data_row(ws_raw, rownum, record, dates_ascending)
        ws_raw.freeze_panes = "C5"
        ws_raw.auto_filter.ref = f"A4:{get_column_letter(2 + len(dates_ascending))}{4 + len(data)}"

        # Sheet 3: COB x Report matrix and a native, editable Excel line chart.
        report_names = list(totals.index)
        for idx, value in enumerate(["COB Date", *report_names], 1):
            ws_chart.cell(5, idx, value)
        format_header_row(ws_chart, 5, len(report_names) + 1)
        for rownum, col in enumerate(dates_ascending, start=6):
            ws_chart.cell(rownum, 1, self.column_dates[col]).number_format = "dd mmm yyyy"
            for idx, report in enumerate(report_names, start=2):
                value = totals.loc[report, col]
                ws_chart.cell(rownum, idx, float(value) if pd.notna(value) else None)
                ws_chart.cell(rownum, idx).number_format = number_fmt
        ws_chart.freeze_panes = "B6"
        ws_chart.auto_filter.ref = f"A5:{get_column_letter(len(report_names) + 1)}{5 + len(dates_ascending)}"
        excel_chart = LineChart()
        excel_chart.title = f"{pnl_measure} P&L Trend by Report"
        excel_chart.style = 13
        excel_chart.y_axis.title = "P&L"
        excel_chart.x_axis.title = "COB Date"
        excel_chart.height = 12
        excel_chart.width = 24
        excel_chart.display_blanks = "gap"
        for colnum in range(2, len(report_names) + 2):
            excel_chart.add_data(
                Reference(ws_chart, min_col=colnum, min_row=5,
                          max_row=5 + len(dates_ascending)),
                titles_from_data=True,
            )
        excel_chart.set_categories(
            Reference(ws_chart, min_col=1, min_row=6,
                      max_row=5 + len(dates_ascending))
        )
        ws_chart.add_chart(excel_chart, f"A{len(dates_ascending) + 9}")

        # Sizing and consistency.
        for ws in (ws_heatmap, ws_raw, ws_chart):
            ws.column_dimensions["A"].width = 26
            ws.column_dimensions["B"].width = 22
            for colnum in range(3, ws.max_column + 1):
                ws.column_dimensions[get_column_letter(colnum)].width = 17
            ws.sheet_properties.pageSetUpPr.fitToPage = True

        output = BytesIO()
        wb.save(output)
        return output.getvalue()
