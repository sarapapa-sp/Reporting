"""Streamlit demo: streamlit run streamlit_gm_trend_demo.py"""

from datetime import date

import pandas as pd
import streamlit as st

from gm_trend_charts import GMTrendCharts


def getrecentcob() -> date:
    """Temporary COB rule: today minus 4 Mon–Fri business days.

    Public/market holidays are NOT considered; replace with your production
    COB-calendar function when available. Uses the server's local date.
    """
    return (pd.Timestamp.today().normalize() - pd.offsets.BDay(4)).date()


def sample_trend_data() -> pd.DataFrame:
    """Sample with recent COB columns; replace with your real trend DataFrame."""
    dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=15)
    df = pd.DataFrame({
        "report_name": ["Revenue", "Revenue", "Costs", "Costs", "Other"],
        "indicator": ["A", "B", "A", "B", "A"],
    })
    for i, cob in enumerate(dates):
        df[cob.strftime("%Y-%m-%d")] = [
            10 + (i % 6), -3 + (i % 5), -10 + (i % 4),
            4 + (i % 3), 6 + (i % 6),
        ]
    return df


st.set_page_config(page_title="GM Trend Analysis", layout="wide")
st.title("Global Markets | Trend Analysis")

# Replace this sample DataFrame with your real, pre-pivoted P&L output.
df_trend = sample_trend_data()

try:
    charts = GMTrendCharts(df_trend)

    left, middle, right, date_col = st.columns([2, 2, 1, 1.5])
    with left:
        selected_reports = st.multiselect(
            "Reports", charts.reports, default=charts.reports,
        )
    with middle:
        selected_indicators = st.multiselect(
            "Indicators (both charts)", charts.indicators,
            default=charts.indicators,
        )
    with right:
        n_cobs = st.number_input(
            "Previous COBs", min_value=1,
            max_value=len(charts.date_columns),
            value=min(5, len(charts.date_columns)), step=1,
        )
    with date_col:
        selected_cob = st.date_input(
            "COB date (as-of)",
            value=getrecentcob(),
            max_value=date.today(),
            format="DD/MM/YYYY",
        )

    if not selected_reports or not selected_indicators:
        st.info("Select at least one report and indicator.")
        st.stop()

    # All three outputs share identical report/indicator, date, and N-COB filters.
    available = charts.available_cobs(end_cob=selected_cob)
    if not available:
        st.warning("No COB data is available on or before the selected date.")
        st.stop()

    effective_cob = available[-1]
    if effective_cob != selected_cob:
        st.info(
            f"No source data for {selected_cob:%d %b %Y}. "
            f"Using the latest available COB: {effective_cob:%d %b %Y}."
        )
    st.caption(
        f"Selected cutoff: {selected_cob:%d %b %Y}  |  "
        f"Latest available COB: {effective_cob:%d %b %Y}  |  "
        f"Showing up to {int(n_cobs)} business-date columns"
    )

    tabs = st.tabs(["Heatmap", "Line Graphs"])
    with tabs[0]:
        heatmap_fig = charts.create_heatmap(
            reports=selected_reports,
            indicators=selected_indicators,
            n_cobs=int(n_cobs),
            end_cob=selected_cob,
        )
        st.plotly_chart(heatmap_fig, use_container_width=True)
    with tabs[1]:
        line_fig = charts.create_line_graph(
            reports=selected_reports,
            indicators=selected_indicators,
            n_cobs=int(n_cobs),
            end_cob=selected_cob,
        )
        st.caption(
            "One line per report. Multiple selected indicators are summed within each report."
        )
        st.plotly_chart(line_fig, use_container_width=True)

    st.subheader("Export")
    excel_bytes = charts.export_trend_report_excel(
        reports=selected_reports,
        indicators=selected_indicators,
        n_cobs=int(n_cobs),
        end_cob=selected_cob,
        pnl_measure="Daily",  # Set according to the DataFrame passed in.
    )
    st.download_button(
        "Download Heatmap + Trends (Excel)",
        data=excel_bytes,
        file_name=f"GM_Trend_Report_{effective_cob:%Y%m%d}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )

except ValueError as exc:
    st.error(str(exc))
