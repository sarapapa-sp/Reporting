Global Markets Trend Analysis - Streamlit, Plotly and Excel
==========================================================
Files:
  gm_trend_charts.py           Chart generation + Excel exporter
  streamlit_gm_trend_demo.py   Streamlit UI with as-of COB date filter
  requirements_gm_trend.txt   Python dependencies

Run:
  pip install -r requirements_gm_trend.txt
  streamlit run streamlit_gm_trend_demo.py

DATA:
  Pre-pivoted dataframe: report_name, indicator, <date>, <date> ...
  COB headers may be date/date-like strings, dates or pandas Timestamps.
  One report/indicator per row. Values may be numeric or missing.

DEFAULT DATE:
  getrecentcob(): server local today - 4 Mon-Fri business days.
  This is a placeholder, and does not consider market holidays.
  Replace getrecentcob() with your own business calendar when ready.

DATE FILTER:
  st.date_input selects an inclusive as-of cutoff (end_cob).
  Charts and export include the last N available COB columns on/before it.
  If the selected date has no data, the latest earlier available COB is used.
  Heatmap/Excel P&L Heatmap: latest COB displayed first (left side).
  Line graphs/Excel Trend Charts: oldest to newest (chronological).

PUBLIC API:
  charts = GMTrendCharts(df_trend)
  charts.create_heatmap(end_cob=selected_cob, n_cobs=5, ...)
  charts.create_line_graph(end_cob=selected_cob, n_cobs=5, ...)
  charts.export_trend_report_excel(end_cob=selected_cob, n_cobs=5,
                                  pnl_measure='Daily', ...)
  charts.available_cobs(end_cob=selected_cob)

Excel workbook contents:
  1. P&L Heatmap - real values, native red/white/green conditional formatting
  2. Trend Data  - report/indicator source data, dates chronological
  3. Trend Charts - report totals and an editable native Excel line chart

IMPORTANT:
  Selected indicators are summed within report for report line graphs.
  Only add indicators together if they are additive, non-overlapping P&L lines.
  Do not sum MTD/YTD across *dates*; each date is an as-of-COB snapshot.
