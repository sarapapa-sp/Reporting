# Publication Trend Dashboard v3

## Install and run
`pip install -r requirements.txt`
`TREND_ROOT=/path/to/monthly/workbooks streamlit run app.py`

Input files: `<root>/<year>/Report_data_<Mon>.xlsx` with `cob_date, version, report_name, indicator, daily` columns (optional additional columns). Input P&L is kEUR; dashboard and Excel output are mEUR.

Default dashboard COB is the latest **Daily** COB discovered across all year/month workbooks. Historical reference excludes selected COB. Minimum reference observations: 5, 60, 100, 7, 10, 20 for short, long, broad, month, quarter, full year. The 100-COB window is distinct from full-year analysis. Distribution is per report/indicator.

## Notes
- This is a standalone implementation based on the publicly accessible analyzer interface, **not a byte-for-byte patch of all previous dashboard scripts**.
- `run_trend_analysis()` returns a dict with `trend` and `history`. Existing downstream consumers requiring other dict keys must be adapted.
- Data continuity and calendar holiday policies should be aligned with the production calendar before deployment.
- Historical workbook loading now walks backward across calendar years until every selected-COB report/indicator has 100 prior COB observations, or the earliest available workbook year is exhausted. If history is insufficient, the period shows `insufficient_data`. Missing months are logged.
- `get_latest_cob_by_version()` scans workbooks; Streamlit caches results for five minutes.
- Percentage change uses absolute first historical observation as denominator.
- Excel export deliberately excludes MTD/YTD.
